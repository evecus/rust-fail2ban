//! Clash-style local API: dashboard UI + JSON endpoints.
//!
//! Connection tracking is controlled by the top-level config key
//! `api-connection-record` (default true = always record live sessions).
//! When set to false, opening `/ui` (or polling `/connections`) arms the
//! tracker for a short TTL; closing the browser stops registration and frees
//! the map.

use crate::app::cache::AppCache;
use crate::app::router::Router;
use crate::app::stats;
use crate::app::ui::{LOGIN_HTML, UI_HTML};
use crate::config::{Config, RulesetConfig};
use crate::outbound::OutboundManager;
use crate::app::proxy_provider::ProxyProviderStore;
use anyhow::{Context, Result};
use http_body_util::Full;
use hyper::body::Bytes;
use hyper::header::{COOKIE, SET_COOKIE};
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::{Method, Request, Response, StatusCode};
use hyper_util::rt::TokioIo;
use std::convert::Infallible;
use std::net::SocketAddr;
use std::sync::{Arc, RwLock};
use tokio::net::TcpListener;

static OUTBOUNDS: RwLock<Option<Arc<OutboundManager>>> = RwLock::new(None);
static ROUTER: RwLock<Option<Arc<Router>>> = RwLock::new(None);
static CONFIG: RwLock<Option<Arc<Config>>> = RwLock::new(None);
/// Live proxy-provider store (None when no `proxy-providers:` are configured).
static PROVIDERS: RwLock<Option<Arc<ProxyProviderStore>>> = RwLock::new(None);
/// Resolved rule-provider configs + optional cache for manual HTTP refresh.
type RulesetCtx = (Vec<RulesetConfig>, Option<Arc<AppCache>>);
static RULESET_CTX: RwLock<Option<RulesetCtx>> = RwLock::new(None);
/// api-secret 鉴权状态：None = 未启用（无 api-secret 字段）。
static AUTH: RwLock<Option<AuthState>> = RwLock::new(None);

/// 鉴权 Cookie 名。登录成功后下发，Max-Age 一年，浏览器持久保存。
const AUTH_COOKIE: &str = "ant_auth";

struct AuthState {
    secret: String,
    /// 登录成功后下发的随机 token（进程内有效）。
    token: String,
}

pub fn set_outbounds(m: Arc<OutboundManager>) {
    *OUTBOUNDS.write().unwrap() = Some(m);
}

pub fn set_router(r: Arc<Router>) {
    *ROUTER.write().unwrap() = Some(r);
}

fn router() -> Option<Arc<Router>> {
    ROUTER.read().unwrap().clone()
}

pub fn set_providers(p: Arc<ProxyProviderStore>) {
    *PROVIDERS.write().unwrap() = Some(p);
}

fn providers() -> Option<Arc<ProxyProviderStore>> {
    PROVIDERS.read().unwrap().clone()
}

/// Wire resolved rule-provider list + cache so the API can hot-refresh
/// `type: http` rulesets on demand.
pub fn set_ruleset_ctx(list: Vec<RulesetConfig>, cache: Option<Arc<AppCache>>) {
    *RULESET_CTX.write().unwrap() = Some((list, cache));
}

fn ruleset_ctx() -> Option<RulesetCtx> {
    RULESET_CTX.read().unwrap().clone()
}

pub fn set_config(c: Arc<Config>) {
    *CONFIG.write().unwrap() = Some(c.clone());
    // Wire connection-recording mode into the stats tracker.
    stats::set_always_record(c.global.api_connection_record);
    if c.global.api_connection_record {
        tracing::info!("api connection record: always-on (api-connection-record: true)");
    } else {
        tracing::info!("api connection record: opt-in while UI open (api-connection-record: false)");
    }
    let secret = c.global.api_secret.clone();
    if secret.is_empty() {
        *AUTH.write().unwrap() = None;
    } else {
        // token 每次启动随机生成：改密码 / 重启即全部失效。
        let token = hex::encode(rand::random::<[u8; 32]>());
        *AUTH.write().unwrap() = Some(AuthState { secret, token });
        tracing::info!("api auth enabled (api-secret set); login required for /ui");
    }
}

fn outbounds() -> Option<Arc<OutboundManager>> {
    OUTBOUNDS.read().unwrap().clone()
}

fn config() -> Option<Arc<Config>> {
    CONFIG.read().unwrap().clone()
}

pub async fn run_api(listen: SocketAddr) -> Result<()> {
    let listener = TcpListener::bind(listen)
        .await
        .with_context(|| format!("api bind {listen}"))?;
    tracing::info!("api panel http://{listen}/ui");
    loop {
        let (stream, peer) = listener.accept().await?;
        tokio::spawn(async move {
            let io = TokioIo::new(stream);
            let svc = service_fn(move |req| handle(req, peer));
            if let Err(e) = http1::Builder::new().serve_connection(io, svc).await {
                tracing::debug!("api conn {peer}: {e}");
            }
        });
    }
}

async fn handle(
    req: Request<hyper::body::Incoming>,
    _peer: SocketAddr,
) -> Result<Response<Full<Bytes>>, Infallible> {
    let path = req.uri().path().to_string();
    let query = req.uri().query().unwrap_or("").to_string();

    // ── api-secret 鉴权门 ────────────────────────────────────────
    // 未携带有效凭证时：POST /login 处理登录；页面路径回登录页；
    // JSON 接口回 401（前端 fetch 包装器收到 401 自动跳回登录）。
    if !authorized(&req) {
        if req.method() == Method::POST && (path == "/login" || path == "/api/login") {
            return Ok(handle_login(req).await);
        }
        if path == "/" || path == "/ui" || path == "/ui/" {
            return Ok(html_static(StatusCode::OK, LOGIN_HTML));
        }
        return Ok(json_msg(StatusCode::UNAUTHORIZED, "unauthorized: login required"));
    }

    match (req.method(), path.as_str()) {
        (&Method::GET, "/") | (&Method::GET, "/ui") | (&Method::GET, "/ui/") => {
            stats::global().touch();
            Ok(html_static(StatusCode::OK, UI_HTML))
        }
        (&Method::GET, "/connections") | (&Method::GET, "/api/connections") => {
            let list = stats::global().list();
            Ok(json_body(StatusCode::OK, &list))
        }
        // mihomo-compatible: close all / close one tracked connection.
        (&Method::DELETE, "/connections") | (&Method::DELETE, "/api/connections") => {
            let n = stats::global().close_all();
            Ok(json_body(
                StatusCode::OK,
                &serde_json::json!({ "closed": n }),
            ))
        }
        (&Method::DELETE, p)
            if p.starts_with("/connections/") || p.starts_with("/api/connections/") =>
        {
            let id_str = p
                .trim_start_matches("/api")
                .trim_start_matches("/connections/")
                .trim_matches('/');
            match id_str.parse::<u64>() {
                Ok(id) if stats::global().close(id) => Ok(json_msg(StatusCode::OK, "closed")),
                Ok(_) => Ok(json_msg(StatusCode::NOT_FOUND, "connection not found")),
                Err(_) => Ok(json_msg(StatusCode::BAD_REQUEST, "invalid connection id")),
            }
        }
        (&Method::GET, "/proxies") | (&Method::GET, "/api/proxies") => {
            let body = match outbounds() {
                Some(m) => m.group_status(),
                None => Vec::new(),
            };
            Ok(json_body(StatusCode::OK, &body))
        }
        (&Method::GET, "/configs") | (&Method::GET, "/api/configs") => {
            Ok(json_body(StatusCode::OK, &build_info()))
        }
        // ── mihomo-compatible provider endpoints ──────────────────
        // GET  /providers/proxies            — list every proxy-provider
        // GET  /providers/proxies/{name}     — one provider
        // PUT  /providers/proxies/{name}     — re-fetch (pull subscription)
        (&Method::GET, "/providers/proxies") | (&Method::GET, "/api/providers/proxies") => {
            let list = providers().map(|p| p.snapshot()).unwrap_or_default();
            Ok(json_body(
                StatusCode::OK,
                &serde_json::json!({ "providers": list }),
            ))
        }
        (&Method::GET, p)
            if p.starts_with("/providers/proxies/") || p.starts_with("/api/providers/proxies/") =>
        {
            let name = percent_decode(provider_name_from_path(p));
            let Some(store) = providers() else {
                return Ok(json_msg(
                    StatusCode::SERVICE_UNAVAILABLE,
                    "proxy-providers not configured",
                ));
            };
            match store
                .snapshot()
                .into_iter()
                .find(|v| v.get("name").and_then(|n| n.as_str()) == Some(name.as_str()))
            {
                Some(v) => Ok(json_body(StatusCode::OK, &v)),
                None => Ok(json_msg(StatusCode::NOT_FOUND, "provider not found")),
            }
        }
        (&Method::PUT, p)
            if p.starts_with("/providers/proxies/") || p.starts_with("/api/providers/proxies/") =>
        {
            let name = percent_decode(provider_name_from_path(p));
            let Some(m) = outbounds() else {
                return Ok(json_msg(StatusCode::SERVICE_UNAVAILABLE, "outbounds not ready"));
            };
            match m.update_provider(&name).await {
                Ok(n) => Ok(json_body(
                    StatusCode::OK,
                    &serde_json::json!({ "message": "ok", "name": name, "count": n }),
                )),
                Err(e) => Ok(json_msg(
                    StatusCode::SERVICE_UNAVAILABLE,
                    &format!("{e:#}"),
                )),
            }
        }
        // PUT /providers/rules/{name} — re-fetch a type:http rule-provider and
        // hot-reload it. On failure the previous ruleset is kept; ant keeps
        // running.
        (&Method::PUT, p)
            if p.starts_with("/providers/rules/") || p.starts_with("/api/providers/rules/") =>
        {
            let name = percent_decode(ruleset_name_from_path(p));
            let Some((list, cache)) = ruleset_ctx() else {
                return Ok(json_msg(
                    StatusCode::SERVICE_UNAVAILABLE,
                    "rule-providers not configured",
                ));
            };
            let Some(rs) = list.into_iter().find(|r| r.name == name) else {
                return Ok(json_msg(StatusCode::NOT_FOUND, "ruleset not found"));
            };
            if !rs.provider_type.eq_ignore_ascii_case("http") {
                return Ok(json_msg(
                    StatusCode::BAD_REQUEST,
                    "only type: http rule-providers can be refreshed",
                ));
            }
            let Some(router) = router() else {
                return Ok(json_msg(StatusCode::SERVICE_UNAVAILABLE, "router not ready"));
            };
            match crate::ruleset::refresh_remote(&rs, cache.as_deref()).await {
                Ok(loaded) => {
                    let count = loaded.rule_count;
                    router.replace_ruleset(&name, loaded);
                    Ok(json_body(
                        StatusCode::OK,
                        &serde_json::json!({
                            "message": "ok",
                            "name": name,
                            "count": count,
                        }),
                    ))
                }
                Err(e) => {
                    // Keep the old ruleset; do not touch the router.
                    tracing::warn!(
                        name = %name,
                        error = %e,
                        "manual ruleset refresh failed; keeping previous data"
                    );
                    Ok(json_msg(
                        StatusCode::SERVICE_UNAVAILABLE,
                        &format!("refresh failed (old ruleset kept): {e:#}"),
                    ))
                }
            }
        }
        (&Method::GET, "/logs") | (&Method::GET, "/api/logs") => {
            // Optional ?limit=N (default all buffered, max 2000).
            let limit = req
                .uri()
                .query()
                .and_then(|q| {
                    q.split('&').find_map(|p| {
                        let mut it = p.splitn(2, '=');
                        match (it.next(), it.next()) {
                            (Some("limit"), Some(v)) => v.parse::<usize>().ok(),
                            _ => None,
                        }
                    })
                });
            let lines = crate::app::log_buffer::list(limit);
            Ok(json_body(StatusCode::OK, &lines))
        }
        (&Method::DELETE, "/logs") | (&Method::DELETE, "/api/logs") => {
            crate::app::log_buffer::clear();
            Ok(json_msg(StatusCode::OK, "cleared"))
        }
        // PUT /proxies/{group}
        (&Method::PUT, p)
            if p.starts_with("/proxies/") || p.starts_with("/api/proxies/") =>
        {
            let rest = p
                .trim_start_matches("/api")
                .trim_start_matches("/proxies/")
                .trim_matches('/');
            // delay endpoint is GET only; if path ends with /delay, 405
            if rest.ends_with("/delay") {
                return Ok(json_msg(StatusCode::METHOD_NOT_ALLOWED, "use GET for delay"));
            }
            let group = rest;
            let body = match read_body(req).await {
                Ok(b) => b,
                Err(e) => return Ok(json_msg(StatusCode::BAD_REQUEST, &format!("body: {e}"))),
            };
            let name = serde_json::from_slice::<serde_json::Value>(&body)
                .ok()
                .and_then(|v| v.get("name").and_then(|n| n.as_str()).map(|s| s.to_string()));
            let Some(member) = name else {
                return Ok(json_msg(
                    StatusCode::BAD_REQUEST,
                    "JSON body must include {\"name\":\"member\"}",
                ));
            };
            let Some(m) = outbounds() else {
                return Ok(json_msg(StatusCode::SERVICE_UNAVAILABLE, "outbounds not ready"));
            };
            match m.set_group(group, &member) {
                Ok(()) => Ok(json_msg(StatusCode::OK, "ok")),
                Err(e) => Ok(json_msg(StatusCode::BAD_REQUEST, &format!("{e:#}"))),
            }
        }
        // GET /proxies/{name}/delay?url=&timeout=
        (&Method::GET, p)
            if (p.starts_with("/proxies/") || p.starts_with("/api/proxies/"))
                && p.ends_with("/delay") =>
        {
            let rest = p
                .trim_start_matches("/api")
                .trim_start_matches("/proxies/")
                .trim_end_matches("/delay")
                .trim_matches('/');
            let name = percent_decode(rest);
            // DIRECT 默认用小米 204（国内直连可达）；其它节点默认 gstatic。
            // 请求带 ?url= 时仍以参数为准。
            let mut url = if name.eq_ignore_ascii_case("direct") {
                "http://connect.rom.miui.com/generate_204".to_string()
            } else {
                "http://www.gstatic.com/generate_204".to_string()
            };
            let mut timeout_ms: u64 = 5000;
            for pair in query.split('&') {
                let mut it = pair.splitn(2, '=');
                let k = it.next().unwrap_or("");
                let v = it.next().unwrap_or("");
                if k == "url" {
                    url = percent_decode(v);
                } else if k == "timeout" {
                    timeout_ms = v.parse().unwrap_or(5000);
                }
            }
            let Some(m) = outbounds() else {
                return Ok(json_msg(StatusCode::SERVICE_UNAVAILABLE, "outbounds not ready"));
            };
            let name2 = name.clone();
            let url2 = url.clone();
            let fut = m.delay(&name2, &url2);
            let delay = match tokio::time::timeout(
                std::time::Duration::from_millis(timeout_ms.max(500)),
                fut,
            )
            .await
            {
                Ok(Some(ms)) => ms as i64,
                _ => -1,
            };
            Ok(json_body(
                StatusCode::OK,
                &serde_json::json!({ "delay": delay, "name": name, "url": url }),
            ))
        }
        _ => Ok(html_static(
            StatusCode::NOT_FOUND,
            "<!doctype html><title>404</title><p>not found. try <a href=\"/ui\">/ui</a>",
        )),
    }
}

// ── api-secret 鉴权 ─────────────────────────────────────────────

/// 请求是否已授权：未配置 api-secret 一律放行；否则校验 Cookie
/// `ant_auth=<token>` 或 `Authorization: Bearer <token>`。
fn authorized(req: &Request<hyper::body::Incoming>) -> bool {
    let guard = AUTH.read().unwrap();
    let Some(auth) = guard.as_ref() else {
        return true;
    };
    let cookie_ok = req
        .headers()
        .get_all(COOKIE)
        .iter()
        .filter_map(|v| v.to_str().ok())
        .any(|v| {
            v.split(';').any(|pair| {
                let pair = pair.trim();
                match pair.strip_prefix(AUTH_COOKIE) {
                    Some(rest) => rest.strip_prefix('=') == Some(auth.token.as_str()),
                    None => false,
                }
            })
        });
    if cookie_ok {
        return true;
    }
    req.headers()
        .get("authorization")
        .and_then(|v| v.to_str().ok())
        .and_then(|v| v.strip_prefix("Bearer "))
        .map(|t| ct_eq(t, &auth.token))
        .unwrap_or(false)
}

/// POST /login：body `{"password": "..."}`。成功 → 下发凭证 Cookie（一年有效）。
async fn handle_login(req: Request<hyper::body::Incoming>) -> Response<Full<Bytes>> {
    let body = match read_body(req).await {
        Ok(b) => b,
        Err(e) => return json_msg(StatusCode::BAD_REQUEST, &format!("body: {e}")),
    };
    let password = serde_json::from_slice::<serde_json::Value>(&body)
        .ok()
        .and_then(|v| v.get("password").and_then(|p| p.as_str()).map(|s| s.to_string()));
    let Some(password) = password else {
        return json_msg(StatusCode::BAD_REQUEST, "JSON body must include {\"password\":\"...\"}");
    };
    let guard = AUTH.read().unwrap();
    let Some(auth) = guard.as_ref() else {
        return json_msg(StatusCode::BAD_REQUEST, "api-secret is not configured");
    };
    if !ct_eq(&password, &auth.secret) {
        return json_msg(StatusCode::UNAUTHORIZED, "wrong password");
    }
    Response::builder()
        .status(StatusCode::OK)
        .header(
            SET_COOKIE,
            format!("{AUTH_COOKIE}={}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax", auth.token),
        )
        .header("content-type", "application/json; charset=utf-8")
        .header("cache-control", "no-store")
        .body(Full::new(Bytes::from_static(b"{\"message\":\"ok\"}")))
        .unwrap()
}

/// 常数时间字符串比较（避免时序侧信道泄漏密码/前缀匹配）。
fn ct_eq(a: &str, b: &str) -> bool {
    let (a, b) = (a.as_bytes(), b.as_bytes());
    if a.len() != b.len() {
        return false;
    }
    let mut diff = 0u8;
    for i in 0..a.len() {
        diff |= a[i] ^ b[i];
    }
    diff == 0
}

fn bind_is_lan(bind: &str) -> bool {
    let b = bind.trim();
    // Loopback-only → not LAN; anything else (0.0.0.0 / :: / specific NIC IP) → LAN.
    !(b == "127.0.0.1" || b == "::1" || b.eq_ignore_ascii_case("localhost"))
}

fn effective_ipv6(c: &crate::config::Config) -> bool {
    c.global.ipv6
}

fn build_info() -> serde_json::Value {
    let Some(c) = config() else {
        return serde_json::json!({});
    };
    // Prefer runtime-loaded rule counts; fall back to config names with count 0.
    let rule_providers: Vec<serde_json::Value> = if let Some(r) = router() {
        r.ruleset_stats()
            .into_iter()
            .map(|(name, count)| {
                let behavior = c
                    .rule_providers
                    .get(&name)
                    .map(|p| p.behavior.clone())
                    .unwrap_or_default();
                let ty = c
                    .rule_providers
                    .get(&name)
                    .map(|p| p.ty.clone())
                    .unwrap_or_default();
                serde_json::json!({
                    "name": name,
                    "type": ty,
                    "behavior": behavior,
                    "count": count,
                })
            })
            .collect()
    } else {
        c.rule_providers
            .iter()
            .map(|(name, p)| {
                serde_json::json!({
                    "name": name,
                    "type": p.ty,
                    "behavior": p.behavior,
                    "count": 0,
                })
            })
            .collect()
    };
    // Prefer the live store (runtime node counts / updatedAt / errors); fall
    // back to the parsed config when the store is not wired up yet.
    let proxy_providers: Vec<serde_json::Value> = match providers() {
        Some(p) => p.snapshot(),
        None => c
            .proxy_providers
            .iter()
            .map(|(name, pp)| {
                serde_json::json!({
                    "name": name,
                    "type": "Proxy",
                    "vehicleType": if pp.ty.eq_ignore_ascii_case("http") { "HTTP" } else { "File" },
                    "providerType": pp.ty,
                    "url": pp.url,
                    "path": pp.path.as_ref().map(|p| p.display().to_string()),
                    "interval-time": pp.interval_time,
                    "count": 0,
                    "proxies": [],
                    "updatedAt": serde_json::Value::Null,
                    "subscriptionInfo": serde_json::Value::Null,
                    "error": serde_json::Value::Null,
                })
            })
            .collect(),
    };
    let bind = &c.global.bind_address;
    serde_json::json!({
        "proxy_providers": proxy_providers,
        "mixed_port": c.global.mixed_port.unwrap_or(0),
        "http_port": c.global.http_port.unwrap_or(0),
        "socks_port": c.global.socks_port.unwrap_or(0),
        "tproxy_port": c.global.tproxy_port.unwrap_or(0),
        "redir_port": c.global.redir_port.unwrap_or(0),
        "dns_port": if c.dns.enable { serde_json::json!(c.dns.listen_port()) } else { serde_json::Value::Null },
        "bind_address": bind,
        "lan": bind_is_lan(bind),
        "ipv6": effective_ipv6(&c),
        "tun_enable": c.tun.enable,
        "rule_providers": rule_providers,
        "route": c.route,
    })
}

/// `/providers/proxies/{name}` (with optional `/api` prefix) → `{name}`.
fn provider_name_from_path(p: &str) -> &str {
    p.trim_start_matches("/api")
        .trim_start_matches("/providers/proxies/")
        .trim_matches('/')
}

/// `/providers/rules/{name}` (with optional `/api` prefix) → `{name}`.
fn ruleset_name_from_path(p: &str) -> &str {
    p.trim_start_matches("/api")
        .trim_start_matches("/providers/rules/")
        .trim_matches('/')
}

fn percent_decode(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        match bytes[i] {
            b'%' if i + 2 < bytes.len() => {
                let h = hex(bytes[i + 1]);
                let l = hex(bytes[i + 2]);
                if let (Some(h), Some(l)) = (h, l) {
                    out.push((h << 4) | l);
                    i += 3;
                    continue;
                }
                out.push(bytes[i]);
                i += 1;
            }
            b'+' => {
                out.push(b' ');
                i += 1;
            }
            b => {
                out.push(b);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).into_owned()
}

fn hex(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        b'a'..=b'f' => Some(b - b'a' + 10),
        b'A'..=b'F' => Some(b - b'A' + 10),
        _ => None,
    }
}

fn html_static(status: StatusCode, body: &'static str) -> Response<Full<Bytes>> {
    Response::builder()
        .status(status)
        .header("content-type", "text/html; charset=utf-8")
        .header("cache-control", "no-store")
        .body(Full::new(Bytes::from_static(body.as_bytes())))
        .unwrap()
}

fn json_body<T: serde::Serialize>(status: StatusCode, val: &T) -> Response<Full<Bytes>> {
    let body = serde_json::to_vec(val).unwrap_or_else(|_| b"{}".to_vec());
    Response::builder()
        .status(status)
        .header("content-type", "application/json; charset=utf-8")
        .header("cache-control", "no-store")
        .body(Full::new(Bytes::from(body)))
        .unwrap()
}

async fn read_body(req: Request<hyper::body::Incoming>) -> Result<Vec<u8>, String> {
    use http_body_util::BodyExt;
    let collected = req
        .into_body()
        .collect()
        .await
        .map_err(|e| e.to_string())?;
    Ok(collected.to_bytes().to_vec())
}

fn json_msg(status: StatusCode, msg: &str) -> Response<Full<Bytes>> {
    let body = serde_json::json!({ "message": msg }).to_string();
    Response::builder()
        .status(status)
        .header("content-type", "application/json; charset=utf-8")
        .body(Full::new(Bytes::from(body)))
        .unwrap()
}

/// Parse `host:port` or `:port` or `port` into a listen address (default host 127.0.0.1).
pub fn parse_listen(s: &str) -> Result<SocketAddr> {
    let s = s.trim();
    if let Ok(a) = s.parse::<SocketAddr>() {
        return Ok(a);
    }
    if let Ok(port) = s.parse::<u16>() {
        return Ok(SocketAddr::from(([127, 0, 0, 1], port)));
    }
    if let Some(rest) = s.strip_prefix(':') {
        let port: u16 = rest.parse().context("api port")?;
        return Ok(SocketAddr::from(([127, 0, 0, 1], port)));
    }
    // host:port without brackets
    if let Some((h, p)) = s.rsplit_once(':') {
        let port: u16 = p.parse().context("api port")?;
        let ip: std::net::IpAddr = h.parse().context("api host")?;
        return Ok(SocketAddr::new(ip, port));
    }
    anyhow::bail!("invalid api listen address: {s}")
}
