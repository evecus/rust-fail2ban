//! YAML configuration for ant (mihomo-style layout).

use anyhow::{bail, Context, Result};
use serde::Deserialize;
use std::collections::HashMap;
use std::path::PathBuf;

#[derive(Debug, Clone, Deserialize)]
pub struct Config {
    /// Flat top-level keys (mihomo-style): mixed-port, http-port, socks-port, log-level, …
    #[serde(flatten)]
    pub global: GlobalConfig,
    /// DNS 模块。整块省略 = 不启用（走系统 DNS）；块内 `enable: false` 同效。
    #[serde(default)]
    pub dns: DnsConfig,
    /// TUN virtual NIC (optional). System stack + optional OS route/DNS integration.
    #[serde(default)]
    pub tun: TunConfig,
    /// Linux system-wide transparent proxy: nft/iptables + policy routing.
    /// Mutually exclusive with `tun.auto-route` / `tun.auto-redirect`.
    #[serde(default, rename = "ip-auto-route")]
    pub ip_auto_route: IpAutoRouteConfig,
    /// Proxy nodes: list under `proxies:`; each node has a unique `name`.
    #[serde(default)]
    pub proxies: Vec<ProxyConfig>,
    /// Proxy groups (mihomo-style): `select` / `url-test` / `fallback`.
    /// Group names are valid rule outbounds (like node names).
    #[serde(default, rename = "proxy-groups")]
    pub proxy_groups: Vec<ProxyGroupConfig>,
    /// Proxy providers (mihomo-style map). Currently `type: file` only.
    #[serde(default, rename = "proxy-providers")]
    pub proxy_providers: HashMap<String, ProxyProviderConfig>,
    /// Local rule providers (mihomo-style map).
    #[serde(default, rename = "rule-providers")]
    pub rule_providers: HashMap<String, RuleProviderConfig>,
    /// mihomo-style route strings: `RULE-SET,name,outbound` / `MATCH,outbound`.
    /// Outbound: `direct`/`DIRECT`, `block`/`BLOCK`, `reject`/`REJECT`, or a
    /// `proxies` node name (reserved names are rejected for node names).
    #[serde(default)]
    pub route: Vec<String>,
}

/// TUN 协议栈选择（mihomo `tun.stack` 同名语义，默认用户态栈）。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum TunStack {
    /// 用户态协议栈（smoltcp），默认。
    #[default]
    Gvisor,
    /// 内核 NAT 栈（旧行为）。
    System,
    /// 混合栈（sing-tun `mixed` 语义）：TCP/ICMP 走 system 栈（内核 NAT +
    /// 本地 listener），UDP 走 gvisor 用户态栈。
    Mixed,
}

/// Flat `tun:` block. Creates a virtual NIC and runs the selected stack
/// (`gvisor` user-space stack by default, `system` NAT stack opt-in).
/// Optional OS integration: dns-hijack / auto-route / auto-detect-interface /
/// auto-redirect (Linux) / strict-route — see field docs.
#[derive(Debug, Clone, Deserialize)]
pub struct TunConfig {
    /// Master switch. Default false.
    #[serde(default)]
    pub enable: bool,
    /// 协议栈。`gvisor`（默认）：用户态 smoltcp 栈（对齐 clash-rs
    /// clash-netstack / mihomo mipstack 路线），TCP/UDP 全在用户态终结，
    /// 无内核 socket 对（Windows 内存 ↓）、无逐包 NAT 改写（Linux CPU ↓）。
    /// `system`：内核 NAT + 本地 listener 转发（旧行为）。
    /// `mixed`：TCP/ICMP 走 system 栈，UDP 走 gvisor 栈（sing-tun 同名语义）。
    #[serde(default)]
    pub stack: TunStack,
    /// Interface name. Empty → OS assigns (Linux `tunN`; Windows defaults to `ant-tun`).
    #[serde(default)]
    pub device: Option<String>,
    /// External TUN file descriptor (sing-tun `FileDescriptor` equivalent).
    ///
    /// When set (or when env `ANT_TUN_FD` is a positive integer), the process
    /// adopts an already-open TUN fd instead of creating one. Typical sources:
    /// Android `VpnService.Builder.establish()` / iOS PacketTunnelProvider.
    ///
    /// In this mode the OS (VpnService) already owns addresses and routing, so
    /// `auto-route` / `auto-redirect` / OS address configuration are skipped.
    /// Unix only; ignored on Windows.
    #[serde(default, rename = "file-descriptor")]
    pub file_descriptor: Option<i32>,
    /// Whether to close `file-descriptor` when the TUN device is dropped.
    /// Default true (take ownership). Set false if the caller retains ownership
    /// (e.g. JNI side will close the ParcelFileDescriptor).
    /// Consumed only on Unix (external-FD path in `tun::device`).
    #[cfg_attr(not(unix), allow(dead_code))]
    #[serde(default = "default_true", rename = "close-fd-on-drop")]
    pub close_fd_on_drop: bool,
    /// Address prefixes, e.g. `["198.18.0.1/30"]`.
    /// System stack needs server=addr, client=addr+1 inside the prefix — avoid `/32`.
    /// Still required for the in-process system stack even when using an external FD
    /// (values must match what VpnService configured).
    #[serde(default)]
    pub address: Vec<String>,
    /// MTU. Default 1500.
    #[serde(default = "default_tun_mtu")]
    pub mtu: u32,
    /// DNS destinations to intercept inside the TUN stack, e.g. `any:53`, `0.0.0.0:53`.
    /// Matched UDP/TCP port-53 queries are answered by the local DNS module.
    #[serde(default, rename = "dns-hijack")]
    pub dns_hijack: Vec<String>,
    /// Install routes so traffic enters the TUN device (Linux `ip` / Windows `netsh`).
    #[serde(default, rename = "auto-route")]
    pub auto_route: bool,
    /// Bind outbound sockets to the current default physical interface so proxy
    /// traffic does not re-enter TUN (loop prevention). Linux: SO_BINDTODEVICE;
    /// Windows: best-effort (mark/route still required for full isolation).
    #[serde(default, rename = "auto-detect-interface")]
    pub auto_detect_interface: bool,
    /// Linux only: mihomo/sing-tun style auto-redirect (internal listener + nft/iptables).
    /// Uses the classic topology (requires `auto-route`); TCP is handled by the
    /// redirect listener, UDP/ICMP enter the TUN device. Does **not** require
    /// `redir-port`. Ignored on non-Linux.
    #[serde(default, rename = "auto-redirect")]
    pub auto_redirect: bool,
    /// Stronger anti-leak routing on top of auto-route (Linux). May break LAN reachability.
    #[serde(default, rename = "strict-route")]
    pub strict_route: bool,
    /// Custom prefixes routed into TUN when auto-route is on. Empty → split default
    /// (`0.0.0.0/1`+`128.0.0.0/1` and IPv6 equivalents).
    #[serde(default, rename = "route-address")]
    pub route_address: Vec<String>,
    /// Prefixes excluded from auto-route (not installed / explicitly deleted).
    #[serde(default, rename = "route-exclude-address")]
    pub route_exclude_address: Vec<String>,
    /// iproute2 table index for policy routing (Linux). Default 1982.
    #[cfg_attr(
        not(any(target_os = "linux", target_os = "android")),
        allow(dead_code)
    )]
    #[serde(default = "default_tun_table", rename = "iproute2-table-index")]
    pub iproute2_table_index: i32,
    /// iproute2 rule priority (Linux). Default 9000.
    #[cfg_attr(
        not(any(target_os = "linux", target_os = "android")),
        allow(dead_code)
    )]
    #[serde(default = "default_tun_rule", rename = "iproute2-rule-index")]
    pub iproute2_rule_index: i32,
}

impl Default for TunConfig {
    fn default() -> Self {
        Self {
            enable: false,
            stack: TunStack::default(),
            device: None,
            file_descriptor: None,
            close_fd_on_drop: true,
            address: Vec::new(),
            mtu: default_tun_mtu(),
            dns_hijack: Vec::new(),
            auto_route: false,
            auto_detect_interface: false,
            auto_redirect: false,
            strict_route: false,
            route_address: Vec::new(),
            route_exclude_address: Vec::new(),
            iproute2_table_index: default_tun_table(),
            iproute2_rule_index: default_tun_rule(),
        }
    }
}

impl TunConfig {
    /// Resolve external TUN fd: config `file-descriptor` wins, else env `ANT_TUN_FD`.
    /// Returns `None` when neither is a positive integer (create device ourselves).
    pub fn resolved_file_descriptor(&self) -> Option<i32> {
        if let Some(fd) = self.file_descriptor {
            if fd > 0 {
                return Some(fd);
            }
        }
        std::env::var("ANT_TUN_FD")
            .ok()
            .and_then(|s| s.trim().parse::<i32>().ok())
            .filter(|&fd| fd > 0)
    }

    /// True when we adopt an external TUN fd (Android VpnService / iOS / parent).
    pub fn is_external_fd(&self) -> bool {
        self.resolved_file_descriptor().is_some()
    }
}

fn default_tun_table() -> i32 {
    1982
}

fn default_tun_rule() -> i32 {
    9000
}

fn default_tun_mtu() -> u32 {
    1500
}

/// Linux/Android system-wide transparent proxy control plane (`ip-auto-route:`).
///
/// Deploys nftables (preferred) or iptables + policy routing via rtnetlink.
/// Mutually exclusive with `tun.auto-route` / `tun.auto-redirect`.
/// Related base configs (redir/tproxy ports, tun, dns) must be present when
/// the corresponding mode/feature is enabled.
///
/// Fields are consumed only by the Linux-only `ip_auto_route` module; the
/// `cfg_attr` keeps non-Linux builds from reporting them as dead code.
#[cfg_attr(not(target_os = "linux"), allow(dead_code))]
#[derive(Debug, Clone, Deserialize)]
pub struct IpAutoRouteConfig {
    /// Master switch. Default false.
    #[serde(default)]
    pub enable: bool,
    /// Install IPv6 rules/routes as well. Default true.
    #[serde(default = "default_true")]
    pub ipv6: bool,
    /// Hijack DNS (TCP/UDP :53) to the local DNS listen port.
    /// Requires `dns.enable` and a non-zero `dns.port`.
    #[serde(default, rename = "dns-hijack-to-port")]
    pub dns_hijack_to_port: bool,
    /// Special-case ICMP to Fake-IP ranges (requires dns mode=fakeip + ranges).
    #[serde(default, rename = "fakeip-ping-hijack")]
    pub fakeip_ping_hijack: bool,
    /// TCP hijack mode: `redir` | `tproxy` | `tun`. Omit = unused for TCP.
    #[serde(default, rename = "tcp-mode")]
    pub tcp_mode: Option<String>,
    /// UDP hijack mode: `tproxy` | `tun`. Omit = unused for UDP.
    #[serde(default, rename = "udp-mode")]
    pub udp_mode: Option<String>,
    /// Hijack traffic arriving from LAN interfaces (prerouting).
    #[serde(default, rename = "lan-proxy")]
    pub lan_proxy: bool,
    /// LAN ingress interfaces. **Required** (non-empty) when `lan-proxy: true`.
    #[serde(default, rename = "lan-interface")]
    pub lan_interface: Vec<String>,
    /// User-defined UID bypass list (no built-in defaults).
    #[serde(default, rename = "bypass-uid")]
    pub bypass_uid: Vec<u32>,
    /// User-defined GID bypass list.
    #[serde(default, rename = "bypass-gid")]
    pub bypass_gid: Vec<u32>,
    /// User-defined cgroup v2 path bypass list (e.g. `system.slice/sshd.service`).
    #[serde(default, rename = "bypass-cgroup")]
    pub bypass_cgroup: Vec<String>,
    /// Hijack traffic **originating from the local machine** (nft `nat_output` /
    /// `mangle_output`, iptables nat/mangle `OUTPUT`). Default true.
    /// Aligned with nexa `proxy.router_proxy`.
    #[serde(default = "default_true", rename = "router-proxy")]
    pub router_proxy: bool,
    /// LAN source IPv4 addresses that bypass the proxy (nexa `lan_access_control.ip`).
    #[serde(default, rename = "lan-bypass-ip")]
    pub lan_bypass_ip: Vec<String>,
    /// LAN source MAC addresses that bypass the proxy (nexa `lan_access_control.mac`).
    #[serde(default, rename = "lan-bypass-mac")]
    pub lan_bypass_mac: Vec<String>,
    /// Loop-prevention method — how ant's own traffic is recognised and let
    /// through the hijack rules. `cgroup` | `mark`.
    ///
    /// Omitted → `cgroup` when the system has a writable cgroup mount, `mark`
    /// otherwise (nexa `proxy.bypass_cgroup` + its gid fallback).
    /// The two are mutually exclusive by design: with `cgroup` no mark match is
    /// emitted at all, so a stray SO_MARK can never be mistaken for "our" traffic.
    #[serde(default, rename = "bypass-type")]
    pub bypass_type: Option<String>,
    /// cgroup v2 sub-name → `/sys/fs/cgroup/services/<name>`
    /// (nexa `routing.cgroup_name`, default `ant`).
    #[serde(default, rename = "cgroup-name")]
    pub cgroup_name: Option<String>,
    /// cgroup v1 net_cls classid (nexa `routing.cgroup_id`).
    #[serde(default, rename = "cgroup-id")]
    pub cgroup_id: Option<String>,
}

impl Default for IpAutoRouteConfig {
    fn default() -> Self {
        Self {
            enable: false,
            ipv6: true,
            dns_hijack_to_port: false,
            fakeip_ping_hijack: false,
            tcp_mode: None,
            udp_mode: None,
            lan_proxy: false,
            lan_interface: Vec::new(),
            bypass_uid: Vec::new(),
            bypass_gid: Vec::new(),
            bypass_cgroup: Vec::new(),
            router_proxy: true,
            lan_bypass_ip: Vec::new(),
            lan_bypass_mac: Vec::new(),
            bypass_type: None,
            cgroup_name: None,
            cgroup_id: None,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
pub struct GlobalConfig {
    /// `error` | `warn` | `info` | `debug` | `trace` | `off`.
    /// `off` disables logging entirely — runtime output *and* the in-memory
    /// log buffer behind the API/UI. `RUST_LOG` overrides it when set.
    #[serde(default = "default_log_level", rename = "log-level")]
    pub log_level: String,
    /// None = 入站未启用；显式 `0` 会被校验拒绝（想关闭就省略字段）。
    #[serde(default, rename = "tproxy-port")]
    #[cfg_attr(
        not(any(target_os = "linux", target_os = "android")),
        allow(dead_code)
    )]
    pub tproxy_port: Option<u16>,
    #[serde(default, rename = "mixed-port")]
    pub mixed_port: Option<u16>,
    /// Dedicated HTTP inbound (CONNECT + absolute-URI). None = disabled.
    /// Explicit `0` is rejected at validate (omit the field to disable).
    /// Alias `port` matches mihomo / clash flat config.
    #[serde(default, rename = "http-port", alias = "port")]
    pub http_port: Option<u16>,
    /// Dedicated SOCKS4/4a/5 inbound (TCP + SOCKS5 UDP ASSOCIATE). None = disabled.
    /// Explicit `0` is rejected at validate (omit the field to disable).
    #[serde(default, rename = "socks-port", alias = "socks5-port")]
    pub socks_port: Option<u16>,
    /// None = 入站未启用；显式 `0` 会被校验拒绝（想关闭就省略字段）。
    #[serde(default, rename = "redir-port")]
    #[cfg_attr(
        not(any(target_os = "linux", target_os = "android")),
        allow(dead_code)
    )]
    pub redir_port: Option<u16>,
    /// SO_MARK for outbound sockets (anti-loop with TUN auto-route).
    /// If 0 and TUN auto-route/redirect/detect-interface is on, a default (255) is applied at runtime.
    #[serde(default, rename = "mark")]
    pub mark: u32,
    /// Inbound / DNS listen address family control.
    /// - `true` (default / unset): dual-stack — IPv4 + IPv6 traffic, rulesets load both
    ///   IPv4 and IPv6 CIDRs, DNS AAAA controlled independently by `dns.ipv6`.
    /// - `false`: IPv4 only — inbound and DNS listen on IPv4 only, DNS ignores
    ///   `dns.ipv6` (A records only), FakeIP allocates only IPv4, IP rulesets
    ///   load only IPv4 CIDRs.
    #[serde(default = "default_true")]
    pub ipv6: bool,
    /// Listen address for all inbounds and the DNS module.
    /// Only `0.0.0.0` (LAN-accessible) or `127.0.0.1` (loopback-only) are accepted.
    /// Whether IPv6 sockets are also opened is controlled solely by top-level `ipv6`.
    #[serde(default = "default_bind", rename = "bind-address")]
    pub bind_address: String,
    #[serde(default, rename = "api")]
    pub api: String,
    /// API 面板（/ui 及全部 JSON 接口）访问密码。非空时必须先登录：
    /// 浏览器输入密码 → 服务端下发凭证 Cookie → 后续请求自动携带。
    /// 类似 mihomo clash-api 的 secret，但只需密码、无需地址/端口。
    #[serde(default, rename = "api-secret")]
    pub api_secret: String,
    /// 是否常驻记录活跃连接（供 API 面板「连接」页显示）。
    /// - `true`（默认 / 不写）：始终记录当前正在进行的连接；连接结束后自动移除，不会显示死连接。
    /// - `false`：仅在面板打开期间记录（打开 `/ui` 或轮询 `/connections` 后短时生效，关闭后清空）。
    #[serde(default = "default_true", rename = "api-connection-record")]
    pub api_connection_record: bool,
    /// Protocol sniffing (TLS SNI / HTTP Host / QUIC SNI) for domain-based routing.
    /// Off by default. DNS-query sniffing is independent: it follows `dns.route-hijack`.
    #[serde(default)]
    pub sniff: bool,
    /// When true, domain destinations are resolved before matching IP rules /
    /// IP rule-providers. Default false. Per-rule `no-resolve` skips this line.
    #[serde(default, rename = "route-resolve")]
    pub route_resolve: bool,
    /// Global persistent cache (redb). Default false.
    /// When true: DNS, Fake-IP, and select-group choices are stored in redb
    /// (`cache-file`). Rule-providers always use files (never redb).
    #[serde(default)]
    pub cache: bool,
    /// Path to the redb file when `cache: true`. Default `cache.db`.
    #[serde(default = "default_cache_file", rename = "cache-file")]
    pub cache_file: PathBuf,
}

fn default_bind() -> String {
    "0.0.0.0".into()
}

fn default_log_level() -> String {
    "info".into()
}

#[derive(Debug, Clone, Deserialize)]
pub struct DnsConfig {
    /// 总开关。`dns:` 块存在时默认 true；`dns:` 块整体省略时 Default（false，
    /// 即完全不启用 DNS 模块——所有内部解析走系统 resolver）。
    /// port 是否配置不影响启用状态：省略 port = 不监听（仅 route-hijack /
    /// TUN dns-hijack 路径应答）；`port: 0` 校验直接拒绝。
    #[serde(default = "default_true")]
    pub enable: bool,
    /// None = 不监听 DNS 端口（仅经路由劫持应答）；显式 `0` 校验拒绝。
    #[serde(default, rename = "port", alias = "dns-port")]
    pub port: Option<u16>,
    /// rule-follow-route=true 时必填：路由出站为 direct 的域名用此上游解析。
    #[serde(default, rename = "direct-nameserver", alias = "direct-dns")]
    pub direct_nameserver: Option<String>,
    /// rule-follow-route=true 时必填：路由出站为任意节点的域名用此上游解析。
    #[serde(default, rename = "proxy-nameserver", alias = "proxy-dns")]
    pub proxy_nameserver: Option<String>,
    /// Bootstrap 上游（必须纯 IP），用于解析其他 nameserver 与节点 server 域名。
    /// enable=true 时必填。
    #[serde(default, rename = "default-nameserver")]
    pub default_nameserver: Option<String>,
    /// true（默认）：DNS 复用顶层 `route:` 规则匹配域名——出站 direct 用
    /// direct-nameserver、节点用 proxy-nameserver、block/reject 回 rcode://success。
    /// false：用 `dns.rules` 自定义 DNS 路由（见下）。
    #[serde(default = "default_true", rename = "rule-follow-route")]
    pub rule_follow_route: bool,
    /// rule-follow-route=false 时的 DNS 路由表：`RULE-SET,<name>,<upstream>` /
    /// `MATCH,<upstream>`。upstream 只能是 nameserver URL 或 `rcode://success`；
    /// 配置了 rules 时最后一条必须是 MATCH。
    #[serde(default)]
    pub rules: Vec<String>,
    /// rule-follow-route=false 且未配置 dns.rules 时的默认上游（必填）。
    #[serde(default)]
    pub nameserver: Option<String>,
    #[serde(default = "default_dns_mode")]
    pub mode: String,
    #[serde(default, rename = "fakeip-range")]
    pub fakeip_range: Option<String>,
    #[serde(default, rename = "fakeip6-range")]
    pub fakeip6_range: Option<String>,
    /// Domain rulesets deciding fake-ip usage, interpreted by `fakeip-filter-mode`:
    /// blacklist (default) — matched domains stay real-IP, everything else gets fake-ip;
    /// whitelist — only matched domains get fake-ip.
    #[serde(default, rename = "fakeip-filter")]
    pub fakeip_filter: Vec<String>,
    #[serde(default, rename = "fakeip-filter-mode")]
    pub fakeip_filter_mode: String,
    #[serde(default, rename = "route-hijack", alias = "hijack-dns")]
    pub route_hijack: bool,
    #[serde(default = "default_true")]
    pub ipv6: bool,
    #[serde(default = "default_cache_size", rename = "cache-size")]
    pub cache_size: usize,
}

impl Default for DnsConfig {
    /// `dns:` 块整体省略 → 不启用 DNS 模块（全部字段为安全默认值）。
    fn default() -> Self {
        Self {
            enable: false,
            port: None,
            direct_nameserver: None,
            proxy_nameserver: None,
            default_nameserver: None,
            rule_follow_route: true,
            rules: Vec::new(),
            nameserver: None,
            mode: default_dns_mode(),
            fakeip_range: None,
            fakeip6_range: None,
            fakeip_filter: Vec::new(),
            fakeip_filter_mode: String::new(),
            route_hijack: false,
            ipv6: true,
            cache_size: default_cache_size(),
        }
    }
}

impl DnsConfig {
    /// DNS UDP/TCP 监听端口；省略 = 0 = 不监听（仅经路由劫持应答）。
    pub fn listen_port(&self) -> u16 {
        self.port.unwrap_or(0)
    }
}

fn default_dns_mode() -> String {
    "redir-host".into()
}

fn default_cache_size() -> usize {
    4096
}

/// One entry under `proxy-groups:` (mihomo-compatible subset).
///
/// ```yaml
/// proxy-groups:
///   - name: PROXY
///     type: select          # select | url-test | fallback
///     proxies:
///       - hy2-hk
///       - hy2-jp
///       - DIRECT
///   - name: AUTO
///     type: url-test
///     proxies: [hy2-hk, hy2-jp]
///     url: http://www.gstatic.com/generate_204
///     interval: 300        # seconds between probes
/// ```
///
/// Rules reference the group `name` the same way as a proxy node name.
#[derive(Debug, Clone, Deserialize)]
pub struct ProxyGroupConfig {
    pub name: String,
    /// `select` | `url-test` | `fallback` | `load-balance` | `relay`
    #[serde(rename = "type")]
    pub ty: String,
    /// Member names: proxy node names, other group names, or `DIRECT` / `REJECT`.
    #[serde(default)]
    pub proxies: Vec<String>,
    /// Provider names under `proxy-providers:` whose nodes are included.
    #[serde(default)]
    pub r#use: Vec<String>,
    /// Include every node from `proxies:` (mihomo `include-all-proxies`).
    #[serde(default, rename = "include-all-proxies")]
    pub include_all_proxies: bool,
    /// Include every provider (mihomo `include-all-providers`).
    #[serde(default, rename = "include-all-providers")]
    pub include_all_providers: bool,
    /// Regex filter on member names (mihomo ``filter``; `` ` `` separates alternatives).
    #[serde(default)]
    pub filter: Option<String>,
    /// Regex exclude on member names (mihomo ``exclude-filter``).
    #[serde(default, rename = "exclude-filter")]
    pub exclude_filter: Option<String>,
    /// Health-check URL for `url-test` / `fallback` / `load-balance` (default generate_204).
    #[serde(default)]
    pub url: Option<String>,
    /// Probe interval in seconds (default 300).
    #[serde(default)]
    pub interval: Option<u64>,
    /// Initial selected member for `select` (default: first in `proxies`).
    #[serde(default)]
    pub selected: Option<String>,
    /// Tolerance in ms for url-test (default 50).
    #[serde(default)]
    pub tolerance: Option<u32>,
    /// `load-balance` strategy: `round-robin` (default) | `consistent-hashing` | `sticky-sessions`.
    #[serde(default)]
    pub strategy: Option<String>,
}

/// One entry under `proxy-providers:` (mihomo-compatible subset).
///
/// ```yaml
/// proxy-providers:
///   sub:
///     type: http
///     url: https://example.com/sub
///     path: ./providers/sub.yaml   # cache file; created on first fetch
///     interval-time: 12            # hours, number only; 0 = manual only
///   local:
///     type: file
///     path: ./providers/local.yaml # contains a `proxies:` list
/// ```
///
/// Payload format (same as mihomo): a YAML/JSON document with a `proxies:`
/// list, or a base64-encoded blob of that document, or a base64-encoded (or
/// plain) newline-separated list of share links (`ss://`, `vmess://`, …).
#[derive(Debug, Clone, Deserialize)]
pub struct ProxyProviderConfig {
    /// `file` | `http`.
    #[serde(rename = "type")]
    pub ty: String,
    /// Local path. Required for `type: file`; for `type: http` it is the cache
    /// file (defaults to `providers/<name>.yaml` under the run directory).
    #[serde(default)]
    pub path: Option<PathBuf>,
    /// Subscription URL. Required for `type: http`.
    #[serde(default)]
    pub url: Option<String>,
    /// Auto-refresh interval in **hours** (number only — no `s`/`m`/`h`
    /// suffix). `0` or omitted = fetch once at startup (when no cache file
    /// exists), then only on demand (API / UI button).
    #[serde(default, rename = "interval-time")]
    pub interval_time: u64,
    /// Regex keep-filter on node names (mihomo `filter`; `` ` `` separates
    /// alternatives).
    #[serde(default)]
    pub filter: Option<String>,
    /// Regex drop-filter on node names (mihomo `exclude-filter`).
    #[serde(default, rename = "exclude-filter")]
    pub exclude_filter: Option<String>,
    /// Extra request headers for `type: http` (mihomo `header`).
    /// e.g. `{ User-Agent: clash-verge }`.
    #[serde(default)]
    pub header: Option<std::collections::HashMap<String, String>>,
}

/// Shared proxy node config. `type` selects protocol; other fields are type-specific.
///
/// Configured under `proxies:` — multiple nodes, each identified by `name`.
/// Route rules reference nodes by name: `RULE-SET,cn,my-hk` or `MATCH,my-hk`.
/// Reserved (case-insensitive): `direct`, `block`, `reject` (+ internal
/// `final` / `proxy`) — node names must not use any of them.
///
/// ## hysteria2
/// `password`, optional `sni` / `alpn` / `skip-cert-verify` / `fingerprint` / `udp-mtu`
///
/// ## tuic
/// `uuid`, `password`, optional `sni` / `alpn` (default `h3`) / `skip-cert-verify` /
/// `fingerprint` / `congestion-control` = `cubic`(default)|`bbr`|`new_reno` /
/// `heartbeat` (e.g. `"10s"`, default 10s)
///
/// ## anytls
/// `password`, optional `sni` / `alpn` / `skip-cert-verify` / `fingerprint` /
/// `client-fingerprint` (uTLS browser hello). UDP rides sing UoT v2.
///
/// ## vless
/// `uuid` (or `password` as uuid), `network` = `tcp`|`ws`|`xhttp`, `tls` = bool,
/// optional `sni`, `skip-cert-verify`, `ws-path`, `ws-host`,
/// `reality-public-key` / `reality-short-id`, `xhttp-path` / `xhttp-host` / `xhttp-mode`
///
/// ## vmess
/// `uuid` (or `password` as uuid), `cipher` = `auto`(default)|`aes-128-gcm`|
/// `chacha20-poly1305`|`none`|`zero` (`auto` + tls → `zero`), `alter-id` = 0,
/// `network` = `tcp`|`ws`|`xhttp`, `tls` = bool, optional `sni`, `skip-cert-verify`,
/// `client-fingerprint` (uTLS), `ws-path` / `ws-host`,
/// `xhttp-path` / `xhttp-host` / `xhttp-mode`
///
/// ## shadowsocks (`ss`)
/// `password` (+ `cipher` / `method` 指定加密方式), `network` = `tcp`|`ws`|`xhttp`,
/// 可选 `sni` / `skip-cert-verify` / `client-fingerprint` (uTLS) /
/// `ws-path` / `ws-host` / `xhttp-*`。
/// 注意两点：
/// * **TLS 默认关闭**。`tls` 字段的全局默认值是 true，但 SS 只在显式给出 `sni`
///   （或 `servername`）、或配置了 `client-fingerprint` 时才启用 TLS —— 没有 SNI
///   的 TLS 握手没有意义。想彻底关闭写 `tls: false`。
/// * **UDP 只在 `network: tcp` 下可用**。SS 的 UDP 是原生 UDP 中继，ws / xhttp
///   承载的是 TCP 流，没有 UDP-over-TCP 约定，`dial_udp` 会直接报错。
#[derive(Debug, Clone, Deserialize)]
#[allow(dead_code)]
pub struct ProxyConfig {
    /// Node name referenced by rules (`MATCH` / `RULE-SET` outbound).
    #[serde(default)]
    pub name: String,

    #[serde(rename = "type")]
    pub ty: String,
    pub server: String,
    pub port: u16,

    #[serde(default)]
    pub password: Option<String>,

    /// SOCKS5 username (RFC 1929). With `password`; omit both for no-auth.
    /// For `socks4` / `socks4a` it is sent as the USERID field (no password).
    #[serde(default)]
    pub username: Option<String>,

    /// SOCKS protocol version for `type: socks`: `"5"` (default), `"4a"` or `"4"`.
    /// Ignored for the explicit `socks5` / `socks4a` / `socks4` types (a
    /// conflicting value is rejected).
    #[serde(default)]
    pub version: Option<String>,

    #[serde(default)]
    pub uuid: Option<String>,

    /// VLESS flow，目前仅支持 `xtls-rprx-vision`（XTLS Vision，TCP/REALITY 专用）。
    #[serde(default)]
    pub flow: Option<String>,

    /// VMess 内层加密方式 / Shadowsocks 加密方法（mihomo 字段名 `cipher`，
    /// 别名 `security`；sing-box 的 `method` 也可识别）：
    /// * vmess：`auto`(默认) | `aes-128-gcm` | `chacha20-poly1305` | `none` | `zero`
    ///   （`auto` + tls 时降级为 `zero`，外层 TLS 已加密，内层冗余；仅 AEAD，
    ///   不支持 `aes-128-cfb`）
    /// * shadowsocks：`aes-128-gcm` | `aes-256-gcm` | `chacha20-ietf-poly1305` |
    ///   `2022-blake3-aes-128-gcm` | `2022-blake3-aes-256-gcm` |
    ///   `2022-blake3-chacha20-poly1305` | `none`
    #[serde(default, rename = "cipher", alias = "security", alias = "method")]
    pub cipher: Option<String>,
    /// VMess `alterId`。仅支持 AEAD 模式（0），非 0 在校验阶段 fail-fast。
    #[serde(default, rename = "alter-id", alias = "alterId")]
    pub alter_id: Option<u32>,

    /// Transport: `tcp` (default), `ws`, or `xhttp` (VLESS).
    #[serde(default = "default_network")]
    pub network: String,

    #[serde(default = "default_true")]
    pub tls: bool,

    #[serde(default)]
    pub sni: Option<String>,
    #[serde(default, rename = "servername")]
    pub servername: Option<String>,

    #[serde(default)]
    pub alpn: Option<Vec<String>>,
    #[serde(default, rename = "skip-cert-verify")]
    pub skip_cert_verify: bool,
    #[serde(default)]
    pub fingerprint: Option<String>,
    /// vless uTLS 浏览器指纹（clash `client-fingerprint` 字段）。
    /// 设置后 VLESS 的 TLS 握手发送浏览器形状的 ClientHello。
    #[serde(default, rename = "client-fingerprint")]
    pub client_fingerprint: Option<String>,

    #[serde(default, rename = "ws-path")]
    pub ws_path: Option<String>,
    #[serde(default, rename = "ws-host")]
    pub ws_host: Option<String>,
    #[serde(default, rename = "ws-headers")]
    pub ws_headers: Option<std::collections::HashMap<String, String>>,

    /// Server x25519 public key (base64 / base64url). Non-empty enables REALITY.
    #[serde(default, rename = "reality-public-key", alias = "public-key")]
    pub reality_public_key: Option<String>,
    /// REALITY shortId (hex, 0..16 chars).
    #[serde(default, rename = "reality-short-id", alias = "short-id")]
    pub reality_short_id: Option<String>,

    /// VLESS ECH（Encrypted Client Hello，RFC 9849/9460）。启用后 rustls 客户端
    /// 用 HPKE 把真实 SNI（inner）加密进 outer ClientHello 的 ECH 扩展，outer
    /// SNI 取 ECH 配置中的 public_name，防止链路观察者看到真实域名。
    /// 仅作用于 rustls TLS 路径：与 REALITY / client-fingerprint (uTLS) 互斥
    /// （构建期 fail-fast）。
    #[serde(default, rename = "ech")]
    pub ech: bool,
    /// ECH 配置（PEM `ECH CONFIGS` 块）。设置后不再走 DNS HTTPS RR。
    #[serde(default, rename = "ech-config")]
    pub ech_config: Option<String>,
    /// ECH 配置文件路径（PEM `ECH CONFIGS` 块）。
    #[serde(default, rename = "ech-config-path")]
    pub ech_config_path: Option<std::path::PathBuf>,
    /// DNS HTTPS RR 获取 ECH 配置时使用的查询域名（默认 sni）。
    #[serde(default, rename = "ech-query-server-name")]
    pub ech_query_server_name: Option<String>,

    /// XHTTP path (default `/`).
    #[serde(default, rename = "xhttp-path", alias = "path")]
    pub xhttp_path: Option<String>,
    /// XHTTP Host header (default: SNI / server).
    #[serde(default, rename = "xhttp-host")]
    pub xhttp_host: Option<String>,
    /// `auto` | `stream-one` | `packet-up` | `stream-up` (currently stream-one over HTTP/1.1).
    #[serde(default, rename = "xhttp-mode")]
    pub xhttp_mode: Option<String>,
    /// Extra XHTTP request headers.
    #[serde(default, rename = "xhttp-headers")]
    pub xhttp_headers: Option<std::collections::HashMap<String, String>>,

    #[serde(default)]
    pub obfs: Option<String>,
    #[serde(default, rename = "obfs-password")]
    pub obfs_password: Option<String>,
    #[serde(default)]
    pub up: Option<String>,
    #[serde(default)]
    pub down: Option<String>,
    #[serde(default)]
    pub ports: Option<String>,
    #[serde(default)]
    pub ca: Option<PathBuf>,
    #[serde(default, rename = "disable-mtu-discovery")]
    pub disable_mtu_discovery: bool,
    #[serde(default, rename = "udp-mtu")]
    pub udp_mtu: Option<u32>,

    /// TUIC 拥塞控制：`cubic`（默认）/ `bbr` / `new_reno`（quinn 无独立实现，
    /// 降级为 cubic）。未知值 fail-fast 拒绝启动。
    #[serde(default, rename = "congestion-control")]
    pub congestion_control: Option<String>,
    /// TUIC 应用层心跳间隔（QUIC datagram Heartbeat 帧），如 `"10s"`；默认 10s。
    /// shadowquic 复用为 QUIC 层 keep-alive 间隔（`"off"` / `"0"` 关闭）。
    #[serde(default)]
    pub heartbeat: Option<String>,

    // ── shadowquic 专用 ────────────────────────────────────────────────────
    /// shadowquic：UDP 走 QUIC stream 而不是 datagram。
    /// `false`（默认）用 datagram（类似 TUIC），`true` 用 uni stream。
    /// 代理 HTTP/3 时建议保持 `false`：over-stream 的重传会与 shadowquic 内部
    /// 拥塞控制冲突，并破坏 HTTP/3 的 MTU 探测。
    #[serde(default, rename = "over-stream")]
    pub over_stream: bool,
    /// shadowquic：0-RTT 握手（默认 true）。
    #[serde(default = "default_true")]
    pub zero_rtt: bool,
    /// shadowquic：QUIC 初始 MTU（默认 1300，必须 >= min-mtu 且 >= 1200）。
    #[serde(default, rename = "initial-mtu")]
    pub initial_mtu: Option<u16>,
    /// shadowquic：QUIC 最小 MTU（默认 1290，必须 >= 1200）。
    #[serde(default, rename = "min-mtu")]
    pub min_mtu: Option<u16>,

    // ── wireguard 专用 ─────────────────────────────────────────────────────
    /// WireGuard 本机私钥（base64，32 字节）。fail-fast 必填。
    #[serde(default, rename = "private-key", alias = "private_key")]
    pub private_key: Option<String>,
    /// WireGuard 对端公钥（base64，32 字节）。fail-fast 必填。
    #[serde(default, rename = "peer-public-key", alias = "peer_public_key")]
    pub peer_public_key: Option<String>,
    /// WireGuard 预共享密钥（可选，base64，32 字节）。
    #[serde(default, rename = "pre-shared-key", alias = "pre_shared_key")]
    pub pre_shared_key: Option<String>,
    /// 本机隧道内地址（含前缀），如 `["10.7.0.2/32", "fd42::2/128"]`。
    /// 至少一个；缺 v4 且目标是 v4 时 dial 报错（fail-fast）。
    #[serde(default, rename = "local-address", alias = "local_address")]
    pub local_address: Vec<String>,
    /// WireGuard 隧道 MTU（默认 1420 = 1500 - 80 WG 开销；不含内核接口 60~80 字节余量）。
    #[serde(default, rename = "mtu")]
    pub wg_mtu: Option<u32>,
    /// 持久保活间隔（秒）。默认 25（wireguard-go `PersistentKeepaliveInterval`），
    /// 0 = 关闭。
    #[serde(default, rename = "persistent-keepalive")]
    pub persistent_keepalive: Option<u16>,
}

/// SOCKS upstream protocol version.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SocksVersion {
    V5,
    V4a,
    V4,
}

fn default_network() -> String {
    "tcp".into()
}
fn default_cache_file() -> PathBuf {
    PathBuf::from("cache.db")
}

fn default_true() -> bool {
    true
}

impl ProxyConfig {
    /// Resolve the SOCKS version from `type` (+ `version` for plain `socks`).
    /// Errors for non-socks types or a `version` that conflicts with `type`.
    pub fn socks_version(&self) -> Result<SocksVersion> {
        fn parse(v: &str) -> Result<SocksVersion> {
            match v.trim().to_ascii_lowercase().as_str() {
                "5" | "" => Ok(SocksVersion::V5),
                "4a" => Ok(SocksVersion::V4a),
                "4" => Ok(SocksVersion::V4),
                other => bail!("unsupported socks version `{other}`, expected 5 / 4a / 4"),
            }
        }
        let by_type = match self.ty.to_ascii_lowercase().as_str() {
            "socks5" => Some(SocksVersion::V5),
            "socks4a" => Some(SocksVersion::V4a),
            "socks4" => Some(SocksVersion::V4),
            "socks" => None,
            other => bail!("`{other}` is not a socks type"),
        };
        let by_field = self.version.as_deref().map(parse).transpose()?;
        match (by_type, by_field) {
            (Some(t), Some(f)) if t != f => bail!(
                "type `{}` conflicts with version `{}`",
                self.ty,
                self.version.as_deref().unwrap_or("")
            ),
            (Some(t), _) => Ok(t),
            (None, Some(f)) => Ok(f),
            (None, None) => Ok(SocksVersion::V5),
        }
    }

    pub fn effective_sni(&self) -> String {
        self.sni
            .clone()
            .or_else(|| self.servername.clone())
            .or_else(|| self.ws_host.clone())
            .unwrap_or_else(|| self.server.clone())
    }

    pub fn vless_uuid(&self) -> Result<String> {
        self.uuid
            .clone()
            .or_else(|| self.password.clone())
            .context("vless requires `uuid` (or `password` as uuid)")
    }
}

/// One entry under `rule-providers:`.
///
/// Storage is **always a file** (never redb):
/// 1. Explicit `path` (highest) — absolute, relative, or `file:/abs/path`
/// 2. Else — default file `rules/<name>.<ext>` under the run directory
///    (`-d/--dir` or cwd). Extension is derived from `format`, then the URL
///    path suffix, otherwise `.txt`.
#[derive(Debug, Clone, Deserialize)]
pub struct RuleProviderConfig {
    /// `file` | `http`
    #[serde(default = "default_provider_type", rename = "type")]
    pub ty: String,
    /// `domain` / `ip` / `ipcidr` / `classical`.
    #[serde(default = "default_behavior")]
    pub behavior: String,
    /// Optional format hint: `text` | `yaml` | `json` | `ars` (auto by extension / content).
    #[serde(default)]
    pub format: Option<String>,
    /// Local path or `file:/abs/path`. Optional — see storage priority above.
    #[serde(default)]
    pub path: Option<PathBuf>,
    /// Remote URL when `type: http`.
    #[serde(default)]
    pub url: Option<String>,
    /// Auto-update interval for remote rule-providers, in **hours** (number only).
    /// `0` or omitted = download once at startup, no periodic refresh.
    #[serde(default, rename = "update-interval")]
    pub update_interval: u64,
}

/// Sanitize a provider name into a safe single-path-component file stem.
fn safe_file_stem(name: &str) -> String {
    let mut out = String::with_capacity(name.len());
    for c in name.chars() {
        if c.is_ascii_alphanumeric() || matches!(c, '-' | '_' | '.') {
            out.push(c);
        } else {
            out.push('_');
        }
    }
    if out.is_empty() {
        "provider".into()
    } else {
        out
    }
}

/// Validate a mihomo-style `filter` / `exclude-filter` regex list
/// (`` ` `` separates alternatives) used by proxy-groups and proxy-providers.
fn validate_group_regex(where_: &str, field: &str, pat: &str) -> Result<()> {
    for part in pat.split('`') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        regex::Regex::new(part).map_err(|e| {
            anyhow::anyhow!("{where_}: invalid `{field}` regex `{part}`: {e}")
        })?;
    }
    Ok(())
}

fn default_provider_type() -> String {
    "file".into()
}

fn default_behavior() -> String {
    "domain".into()
}

/// Where a rule-provider payload is read/written (always a filesystem path).
#[derive(Debug, Clone)]
pub enum RulesetStorage {
    /// Filesystem path (explicit or default `rules/<name>.<ext>`).
    File(PathBuf),
}

/// Normalized ruleset descriptor used by the router (derived from rule-providers).
#[derive(Debug, Clone)]
pub struct RulesetConfig {
    pub name: String,
    /// `domain` / `ip` / `classical`.
    pub ty: String,
    pub format: Option<String>,
    /// `file` or `http`.
    pub provider_type: String,
    pub url: Option<String>,
    /// Hours between remote refreshes; 0 = no auto-update.
    pub update_interval: u64,
    pub storage: RulesetStorage,
}

/// Kind of a single route / DNS rule (mihomo-compatible).
#[derive(Debug, Clone)]
pub enum RuleKind {
    RuleSet(String),
    Domain(String),
    DomainSuffix(String),
    DomainKeyword(String),
    DomainRegex(String),
    IpCidr(String),
    SrcIpCidr(String),
    Match,
}

/// Parsed mihomo-style rule line.
#[derive(Debug, Clone)]
pub struct ParsedRule {
    pub kind: RuleKind,
    /// Normalized outbound: `direct` / `block` / node name.
    pub outbound: String,
    /// Skip domain→IP resolve for this rule (`no-resolve` flag).
    pub no_resolve: bool,
}

impl ParsedRule {
    pub fn is_match(&self) -> bool {
        matches!(self.kind, RuleKind::Match)
    }
    pub fn ruleset_name(&self) -> Option<&str> {
        match &self.kind {
            RuleKind::RuleSet(n) => Some(n.as_str()),
            _ => None,
        }
    }
}

/// Outbound names that cannot be used as proxy node names. Case-insensitive:
/// `direct`/`DIRECT`, `block`/`BLOCK`, `reject`/`REJECT` (+ internal `final`,
/// `proxy`) are all reserved.
pub const RESERVED_OUTBOUND_NAMES: &[&str] = &["direct", "block", "final", "proxy", "reject"];

/// Normalize reserved outbound aliases (`DIRECT`→`direct`, `REJECT`→`block`).
pub fn normalize_outbound_name(s: &str) -> String {
    match s.to_ascii_lowercase().as_str() {
        "direct" => "direct".into(),
        "reject" | "block" => "block".into(),
        _ => s.to_string(),
    }
}

fn is_no_resolve_flag(s: &str) -> bool {
    s.eq_ignore_ascii_case("no-resolve")
}

/// Parse a single mihomo-style rule string.
///
/// Supported: DOMAIN, DOMAIN-SUFFIX, DOMAIN-KEYWORD, DOMAIN-REGEX,
/// IP-CIDR, IP-CIDR6, SRC-IP-CIDR, RULE-SET, MATCH.
/// Trailing `no-resolve` skips domain→IP resolution when `route-resolve: true`.
pub fn parse_rule_line(line: &str) -> Result<ParsedRule> {
    let line = line.trim();
    if line.is_empty() {
        bail!("empty rule line");
    }
    let parts: Vec<&str> = line.split(',').map(|s| s.trim()).filter(|s| !s.is_empty()).collect();
    if parts.is_empty() {
        bail!("empty rule line");
    }
    let kind = parts[0].to_ascii_uppercase();
    // Collect no-resolve from any trailing field after the required ones.
    let no_resolve = parts.iter().skip(1).any(|p| is_no_resolve_flag(p));
    // Filter no-resolve out of payload/outbound slots for indexing.
    let core: Vec<&str> = parts.iter().copied().filter(|p| !is_no_resolve_flag(p)).collect();
    match kind.as_str() {
        "RULE-SET" => {
            if core.len() < 3 {
                bail!("RULE-SET needs name and outbound, got: {line}");
            }
            Ok(ParsedRule {
                kind: RuleKind::RuleSet(core[1].to_string()),
                outbound: normalize_outbound_name(core[2]),
                no_resolve,
            })
        }
        "MATCH" => {
            if core.len() < 2 {
                bail!("MATCH needs outbound, got: {line}");
            }
            Ok(ParsedRule {
                kind: RuleKind::Match,
                outbound: normalize_outbound_name(core[1]),
                no_resolve: false,
            })
        }
        "DOMAIN" => {
            if core.len() < 3 {
                bail!("DOMAIN needs domain and outbound, got: {line}");
            }
            Ok(ParsedRule {
                kind: RuleKind::Domain(core[1].to_ascii_lowercase()),
                outbound: normalize_outbound_name(core[2]),
                no_resolve,
            })
        }
        "DOMAIN-SUFFIX" => {
            if core.len() < 3 {
                bail!("DOMAIN-SUFFIX needs suffix and outbound, got: {line}");
            }
            Ok(ParsedRule {
                kind: RuleKind::DomainSuffix(core[1].trim_start_matches('.').to_ascii_lowercase()),
                outbound: normalize_outbound_name(core[2]),
                no_resolve,
            })
        }
        "DOMAIN-KEYWORD" => {
            if core.len() < 3 {
                bail!("DOMAIN-KEYWORD needs keyword and outbound, got: {line}");
            }
            Ok(ParsedRule {
                kind: RuleKind::DomainKeyword(core[1].to_ascii_lowercase()),
                outbound: normalize_outbound_name(core[2]),
                no_resolve,
            })
        }
        "DOMAIN-REGEX" => {
            if core.len() < 3 {
                bail!("DOMAIN-REGEX needs regex and outbound, got: {line}");
            }
            regex::Regex::new(core[1])
                .with_context(|| format!("invalid DOMAIN-REGEX: {}", core[1]))?;
            Ok(ParsedRule {
                kind: RuleKind::DomainRegex(core[1].to_string()),
                outbound: normalize_outbound_name(core[2]),
                no_resolve,
            })
        }
        "IP-CIDR" | "IP-CIDR6" => {
            if core.len() < 3 {
                bail!("{kind} needs cidr and outbound, got: {line}");
            }
            Ok(ParsedRule {
                kind: RuleKind::IpCidr(core[1].to_string()),
                outbound: normalize_outbound_name(core[2]),
                no_resolve,
            })
        }
        "SRC-IP-CIDR" | "SRC-IP-CIDR6" => {
            if core.len() < 3 {
                bail!("{kind} needs cidr and outbound, got: {line}");
            }
            Ok(ParsedRule {
                kind: RuleKind::SrcIpCidr(core[1].to_string()),
                outbound: normalize_outbound_name(core[2]),
                no_resolve,
            })
        }
        other => bail!(
            "unsupported rule type `{other}`: {line}\n\
             supported: DOMAIN, DOMAIN-SUFFIX, DOMAIN-KEYWORD, DOMAIN-REGEX, \
             IP-CIDR, IP-CIDR6, SRC-IP-CIDR, RULE-SET, MATCH"
        ),
    }
}


/// Strip optional `file:` / `file://` prefix from a path string.
fn strip_file_scheme(s: &str) -> &str {
    let s = s.trim();
    if let Some(rest) = s.strip_prefix("file://") {
        return rest;
    }
    if let Some(rest) = s.strip_prefix("file:") {
        return rest;
    }
    s
}

/// Pick a file extension for the default `rules/<name>.<ext>` path.
///
/// Order: explicit `format` → URL path suffix → `"txt"`.
fn ruleset_default_ext(rp: &RuleProviderConfig) -> String {
    if let Some(fmt) = rp.format.as_deref() {
        match fmt.trim().to_ascii_lowercase().as_str() {
            "yaml" | "yml" => return "yaml".into(),
            "json" => return "json".into(),
            "ars" => return "ars".into(),
            "text" | "list" | "txt" => return "txt".into(),
            other if !other.is_empty() => {
                // Unknown but non-empty format string → use as-is (sanitised).
                let clean: String = other
                    .chars()
                    .filter(|c| c.is_ascii_alphanumeric())
                    .collect();
                if !clean.is_empty() {
                    return clean;
                }
            }
            _ => {}
        }
    }
    if let Some(url) = rp.url.as_deref() {
        let path = url.split(['?', '#']).next().unwrap_or(url);
        if let Some(dot) = path.rfind('.') {
            let ext = path[dot + 1..].to_ascii_lowercase();
            match ext.as_str() {
                "yaml" | "yml" => return "yaml".into(),
                "json" => return "json".into(),
                "ars" => return "ars".into(),
                "txt" | "list" | "conf" | "mrs" => {
                    return if ext == "list" { "txt".into() } else { ext };
                }
                _ => {}
            }
        }
    }
    "txt".into()
}

/// Resolve where a rule-provider is stored.
///
/// Always a file (never redb):
/// 1. Explicit `path` (highest)
/// 2. Default file `rules/<name>.<ext>` under `base_dir`
pub fn resolve_ruleset_storage(
    name: &str,
    rp: &RuleProviderConfig,
    base_dir: &std::path::Path,
) -> RulesetStorage {
    if let Some(ref path) = rp.path {
        let raw = path.to_string_lossy();
        let stripped = strip_file_scheme(&raw);
        let p = PathBuf::from(stripped);
        let abs = if p.is_absolute() {
            p
        } else {
            base_dir.join(p)
        };
        return RulesetStorage::File(abs);
    }
    let ext = ruleset_default_ext(rp);
    let stem = safe_file_stem(name);
    RulesetStorage::File(base_dir.join("rules").join(format!("{stem}.{ext}")))
}

fn normalize_behavior(behavior: &str) -> Result<String> {
    match behavior.to_ascii_lowercase().as_str() {
        "domain" => Ok("domain".into()),
        "ip" | "ipcidr" | "ip-cidr" => Ok("ip".into()),
        "classical" => Ok("classical".into()),
        other => bail!(
            "rule-provider behavior must be domain, ip/ipcidr, or classical, got `{other}`"
        ),
    }
}

/// Parsed `dns.rules` line (used when `rule-follow-route: false`).
#[derive(Debug, Clone)]
pub struct ParsedDnsRule {
    pub kind: RuleKind,
    /// Raw upstream value: a nameserver URL or `rcode://success`.
    pub upstream: String,
}

impl ParsedDnsRule {
    pub fn is_match(&self) -> bool {
        matches!(self.kind, RuleKind::Match)
    }
    pub fn ruleset_name(&self) -> Option<&str> {
        match &self.kind {
            RuleKind::RuleSet(n) => Some(n.as_str()),
            _ => None,
        }
    }
}

/// Parse a `dns.rules` line. Same rule types as route; last field is upstream
/// (nameserver URL or `rcode://success`), never an outbound name.
pub fn parse_dns_rule_line(line: &str) -> Result<ParsedDnsRule> {
    let line = line.trim();
    if line.is_empty() {
        bail!("empty dns rule line");
    }
    let parts: Vec<&str> = line.split(',').map(|s| s.trim()).filter(|s| !s.is_empty()).collect();
    if parts.is_empty() {
        bail!("empty dns rule line");
    }
    let kind = parts[0].to_ascii_uppercase();
    // 与文档一致：关键字只能大写（RULE-SET / MATCH / DOMAIN...），
    // 小写直接拒绝而不是静默归一化。
    if parts[0] != kind {
        bail!(
            "dns rules keyword must be uppercase, got `{}` (expected `{kind}`)",
            parts[0]
        );
    }
    match kind.as_str() {
        "RULE-SET" => {
            if parts.len() < 3 {
                bail!("dns rules `RULE-SET` needs <name>,<upstream>, got: {line}");
            }
            Ok(ParsedDnsRule {
                kind: RuleKind::RuleSet(parts[1].to_string()),
                upstream: parts[2].to_string(),
            })
        }
        "MATCH" => {
            if parts.len() < 2 {
                bail!("dns rules `MATCH` needs <upstream>, got: {line}");
            }
            Ok(ParsedDnsRule {
                kind: RuleKind::Match,
                upstream: parts[1].to_string(),
            })
        }
        "DOMAIN" => {
            if parts.len() < 3 {
                bail!("dns rules DOMAIN needs domain and upstream, got: {line}");
            }
            Ok(ParsedDnsRule {
                kind: RuleKind::Domain(parts[1].to_ascii_lowercase()),
                upstream: parts[2].to_string(),
            })
        }
        "DOMAIN-SUFFIX" => {
            if parts.len() < 3 {
                bail!("dns rules DOMAIN-SUFFIX needs suffix and upstream, got: {line}");
            }
            Ok(ParsedDnsRule {
                kind: RuleKind::DomainSuffix(parts[1].trim_start_matches('.').to_ascii_lowercase()),
                upstream: parts[2].to_string(),
            })
        }
        "DOMAIN-KEYWORD" => {
            if parts.len() < 3 {
                bail!("dns rules DOMAIN-KEYWORD needs keyword and upstream, got: {line}");
            }
            Ok(ParsedDnsRule {
                kind: RuleKind::DomainKeyword(parts[1].to_ascii_lowercase()),
                upstream: parts[2].to_string(),
            })
        }
        "DOMAIN-REGEX" => {
            if parts.len() < 3 {
                bail!("dns rules DOMAIN-REGEX needs regex and upstream, got: {line}");
            }
            regex::Regex::new(parts[1])
                .with_context(|| format!("invalid DOMAIN-REGEX: {}", parts[1]))?;
            Ok(ParsedDnsRule {
                kind: RuleKind::DomainRegex(parts[1].to_string()),
                upstream: parts[2].to_string(),
            })
        }
        "IP-CIDR" | "IP-CIDR6" => {
            if parts.len() < 3 {
                bail!("dns rules {kind} needs cidr and upstream, got: {line}");
            }
            Ok(ParsedDnsRule {
                kind: RuleKind::IpCidr(parts[1].to_string()),
                upstream: parts[2].to_string(),
            })
        }
        "SRC-IP-CIDR" | "SRC-IP-CIDR6" => {
            if parts.len() < 3 {
                bail!("dns rules {kind} needs cidr and upstream, got: {line}");
            }
            Ok(ParsedDnsRule {
                kind: RuleKind::SrcIpCidr(parts[1].to_string()),
                upstream: parts[2].to_string(),
            })
        }
        other => bail!(
            "dns rules: unsupported type `{other}` (got: {line})\n\
             supported: DOMAIN, DOMAIN-SUFFIX, DOMAIN-KEYWORD, DOMAIN-REGEX, \
             IP-CIDR, SRC-IP-CIDR, RULE-SET, MATCH"
        ),
    }
}

/// Validate a `dns.rules` upstream value: `rcode://success` or a parseable
/// nameserver URL (udp/tcp/tls/https). Outbound names — reserved words and
/// `proxies` node names — are rejected (fail-fast).
pub fn validate_dns_upstream(upstream: &str, node_names: &[String]) -> Result<()> {
    let lower = upstream.trim().to_ascii_lowercase();
    if lower == "rcode://success" {
        return Ok(());
    }
    if RESERVED_OUTBOUND_NAMES.contains(&lower.as_str())
        || node_names.iter().any(|n| n.to_ascii_lowercase() == lower)
    {
        bail!(
            "dns rules upstream must be a nameserver url or rcode://success, \
             not an outbound name (got `{upstream}`)"
        );
    }
    crate::dns::parse_nameserver(upstream)
        .with_context(|| format!("dns rules upstream `{upstream}`"))
        .map(|_| ())
}

fn known_has(known: &[String], name: &str) -> bool {
    known.iter().any(|k| k.eq_ignore_ascii_case(name))
}

impl Config {
    /// All routable outbound names: reserved + node names + group names.
    pub fn outbound_names(&self) -> Vec<String> {
        RESERVED_OUTBOUND_NAMES
            .iter()
            .filter(|n| **n != "final" && **n != "proxy" && **n != "reject")
            .map(|s| s.to_string())
            .chain(self.proxies.iter().map(|p| p.name.clone()))
            .chain(self.proxy_groups.iter().map(|g| g.name.clone()))
            .collect()
    }

    /// Rulesets derived from `rule-providers` for the router.
    ///
    /// `base_dir`: `-d/--dir` or cwd — used for relative / default paths.
    pub fn ruleset_list(&self, base_dir: Option<&std::path::Path>) -> Result<Vec<RulesetConfig>> {
        let base = base_dir
            .map(|p| p.to_path_buf())
            .unwrap_or_else(|| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));
        let mut out = Vec::with_capacity(self.rule_providers.len());
        for (name, rp) in &self.rule_providers {
            let pty = rp.ty.to_ascii_lowercase();
            if pty != "file" && pty != "http" {
                bail!(
                    "rule-provider `{name}`: type must be `file` or `http` (got `{}`)",
                    rp.ty
                );
            }
            if pty == "http" && rp.url.as_ref().map(|u| u.trim().is_empty()).unwrap_or(true) {
                bail!("rule-provider `{name}`: type http requires `url`");
            }
            let storage = resolve_ruleset_storage(name, rp, &base);
            out.push(RulesetConfig {
                name: name.clone(),
                ty: normalize_behavior(&rp.behavior)?,
                format: rp.format.clone(),
                provider_type: pty,
                url: rp.url.clone(),
                update_interval: rp.update_interval,
                storage,
            });
        }
        Ok(out)
    }

    /// Absolute path for the shared redb cache database.
    pub fn cache_db_path(&self, base_dir: Option<&std::path::Path>) -> PathBuf {
        let p = &self.global.cache_file;
        if p.is_absolute() {
            p.clone()
        } else if let Some(base) = base_dir {
            base.join(p)
        } else {
            p.clone()
        }
    }

    /// Parse and validate all `route:` lines.
    pub fn parsed_rules(&self) -> Result<Vec<ParsedRule>> {
        self.route
            .iter()
            .map(|line| parse_rule_line(line))
            .collect()
    }

    pub fn load(path: &str) -> Result<Self> {
        let raw = std::fs::read_to_string(path)
            .with_context(|| format!("read config {path}"))?;
        let mut cfg: Config = serde_yaml::from_str(&raw).context("parse YAML config")?;
        cfg.validate()?;
        Ok(cfg)
    }

    /// Resolve rule-provider **and** proxy-provider paths against a base
    /// directory (`-d/--dir` mode): relative paths (`cn.ars`, `./rules/cn.ars`,
    /// `rules/cn.ars`, deeper nesting alike) are joined onto `base_dir`;
    /// absolute paths are untouched.
    ///
    /// A `type: http` proxy-provider without an explicit `path` gets the
    /// default cache location `providers/<name>.yaml` under `base_dir`.
    pub fn resolve_ruleset_paths(&mut self, base_dir: &std::path::Path) {
        for rp in self.rule_providers.values_mut() {
            if let Some(ref path) = rp.path {
                let raw = path.to_string_lossy();
                let stripped = strip_file_scheme(&raw);
                let p = PathBuf::from(stripped);
                if p.is_relative() {
                    rp.path = Some(base_dir.join(p));
                } else {
                    rp.path = Some(p);
                }
            }
        }
        for (name, pp) in self.proxy_providers.iter_mut() {
            match pp.path.take() {
                Some(path) => {
                    let p = PathBuf::from(strip_file_scheme(&path.to_string_lossy()));
                    pp.path = Some(if p.is_relative() { base_dir.join(p) } else { p });
                }
                // Only http providers may omit `path` (file requires it, and
                // validate() already rejected a missing path for type file).
                None if pp.ty.eq_ignore_ascii_case("http") => {
                    pp.path = Some(base_dir.join("providers").join(format!(
                        "{}.yaml",
                        safe_file_stem(name)
                    )));
                }
                None => {}
            }
        }
    }

    /// Default cache path for a `type: http` proxy-provider that omits `path`:
    /// `providers/<name>.yaml` (relative to cwd when there is no `-d/--dir`).
    pub fn default_proxy_provider_path(name: &str) -> PathBuf {
        PathBuf::from("providers").join(format!("{}.yaml", safe_file_stem(name)))
    }

    fn validate(&mut self) -> Result<()> {
        // Nodes may come from `proxies:` or entirely from `proxy-providers:`
        // (e.g. a pure subscription setup) — at least one source is required.
        if self.proxies.is_empty() && self.proxy_providers.is_empty() {
            bail!(
                "at least one proxy node under `proxies:` or one entry under `proxy-providers:` is required"
            );
        }
        for (i, p) in self.proxies.iter().enumerate() {
            let label = if p.name.is_empty() {
                format!("proxies[{i}]")
            } else {
                p.name.clone()
            };
            if p.name.is_empty() {
                bail!("proxies[{i}] requires a non-empty `name`");
            }
            if RESERVED_OUTBOUND_NAMES.contains(&p.name.to_ascii_lowercase().as_str()) {
                bail!("proxy node name `{}` is reserved", p.name);
            }
            match p.ty.to_lowercase().as_str() {
                "hysteria2" => {
                    if p.password.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("hysteria2 node `{label}` requires password");
                    }
                }
                // `tuic` / `anytls` 之前漏了这两个分支，节点会被 `other` 分支当成
                // 不支持的类型拒掉（尽管 OutboundManager 已经能构造它们）。
                "tuic" => {
                    if p.uuid.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("tuic node `{label}` requires uuid");
                    }
                    if p.password.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("tuic node `{label}` requires password");
                    }
                }
                "anytls" => {
                    if p.password.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("anytls node `{label}` requires password");
                    }
                }
                "shadowquic" => {
                    // JLS 认证：username(user iv) + password(JLS pwd) 同时参与
                    // QUIC/TLS 层握手，缺任何一个服务端都无法识别。
                    if p.username.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("shadowquic node `{label}` requires username");
                    }
                    if p.password.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("shadowquic node `{label}` requires password");
                    }
                    // SNI 必须等于服务端 jls-upstream 的域名；不能退化成 IP。
                    let sni = p
                        .sni
                        .as_deref()
                        .or(p.servername.as_deref())
                        .unwrap_or("");
                    if sni.is_empty() {
                        bail!("shadowquic node `{label}` requires sni (must match the server's jls-upstream domain)");
                    }
                    if let Some(m) = p.min_mtu {
                        if m < 1200 {
                            bail!("shadowquic node `{label}`: min-mtu must be >= 1200");
                        }
                    }
                    if let Some(m) = p.initial_mtu {
                        if m < p.min_mtu.unwrap_or(1290) {
                            bail!("shadowquic node `{label}`: initial-mtu must be >= min-mtu");
                        }
                    }
                }
                "spectre" => {
                    // JLS 认证：username(user iv) + password(JLS pwd) 同时参与
                    // QUIC/TLS 层握手，缺任何一个服务端都无法识别。
                    if p.username.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("spectre node `{label}` requires username");
                    }
                    if p.password.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("spectre node `{label}` requires password");
                    }
                    // SNI 必须等于服务端的伪装域名（jls-upstream）；不能退化成 IP。
                    let sni = p
                        .sni
                        .as_deref()
                        .or(p.servername.as_deref())
                        .unwrap_or("");
                    if sni.is_empty() {
                        bail!("spectre node `{label}` requires sni (must match the server's camouflage domain)");
                    }
                }
                "naive" => {
                    // NaiveProxy 必然是 TLS + HTTP/2 CONNECT，且必须有 Basic 认证。
                    if !p.tls {
                        bail!("naive node `{label}`: `tls: false` is invalid (naive is always TLS)");
                    }
                    if p.username.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("naive node `{label}` requires username");
                    }
                    if p.password.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("naive node `{label}` requires password");
                    }
                }
                "vless" => {
                    let _ = p.vless_uuid().with_context(|| format!("node `{label}`"))?;
                    let net = p.network.to_lowercase();
                    if net != "tcp" && net != "ws" && net != "xhttp" {
                        bail!(
                            "vless node `{label}` network must be \"tcp\", \"ws\" or \"xhttp\", got {}",
                            p.network
                        );
                    }
                    if let Some(pk) = &p.reality_public_key {
                        if pk.is_empty() {
                            bail!("reality-public-key must not be empty when set");
                        }
                    }
                    if p.ech {
                        if p.reality_public_key.is_some() {
                            bail!(
                                "vless node `{label}`: ech cannot be combined with \
                                 reality-public-key (REALITY is self-implemented TLS 1.3, \
                                 not the rustls ECH path)"
                            );
                        }
                        if !p.tls {
                            bail!("vless node `{label}`: ech requires tls");
                        }
                        if p.client_fingerprint.is_some() {
                            bail!(
                                "vless node `{label}`: ech cannot be combined with \
                                 client-fingerprint (uTLS 由本模块自己构造 ClientHello 并 \
                                 驱动握手，与 rustls 的 ECH 路径互斥)"
                            );
                        }
                    }
                }
                "vmess" => {
                    if p.uuid
                        .as_ref()
                        .or(p.password.as_ref())
                        .map(|s| s.is_empty())
                        .unwrap_or(true)
                    {
                        bail!("vmess node `{label}` requires uuid (or password as uuid)");
                    }
                    let net = p.network.to_lowercase();
                    if net != "tcp" && net != "ws" && net != "xhttp" {
                        bail!(
                            "vmess node `{label}` network must be \"tcp\", \"ws\" or \"xhttp\", got {}",
                            p.network
                        );
                    }
                    // 只实现 AEAD（alterId = 0）；旧 MD5 认证头不支持。
                    if let Some(alter) = p.alter_id {
                        if alter != 0 {
                            bail!(
                                "vmess node `{label}`: alterId={alter} is not supported \
                                 (only AEAD / alterId=0)"
                            );
                        }
                    }
                }
                "trojan" => {
                    if p.password.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("trojan node `{label}` requires password");
                    }
                    let net = p.network.to_lowercase();
                    if net != "tcp" && net != "ws" && net != "xhttp" {
                        bail!(
                            "trojan node `{label}` network must be \"tcp\", \"ws\" or \"xhttp\", got {}",
                            p.network
                        );
                    }
                }
                "shadowsocks" | "ss" => {
                    if p.password.as_ref().map(|s| s.is_empty()).unwrap_or(true) {
                        bail!("shadowsocks node `{label}` requires password");
                    }
                    let method = p
                        .cipher
                        .as_deref()
                        .map(|s| s.trim())
                        .filter(|s| !s.is_empty())
                        .with_context(|| {
                            format!("shadowsocks node `{label}` requires `cipher` (or `method`)")
                        })?;
                    crate::outbound::validate_ss_method(method)
                        .with_context(|| format!("shadowsocks node `{label}`"))?;
                    let net = p.network.to_lowercase();
                    if net != "tcp" && net != "ws" && net != "xhttp" {
                        bail!(
                            "shadowsocks node `{label}` network must be \"tcp\", \"ws\" or \"xhttp\", got {}",
                            p.network
                        );
                    }
                    if p.client_fingerprint.is_some() && !p.tls {
                        bail!("shadowsocks node `{label}`: client-fingerprint requires tls");
                    }
                }
                "socks5" | "socks" | "socks4" | "socks4a" => {
                    if p.server.is_empty() {
                        bail!("socks node `{label}` requires server");
                    }
                    let ver = p.socks_version().with_context(|| format!("node `{label}`"))?;
                    let u = p.username.as_deref().unwrap_or("");
                    let pw = p.password.as_deref().unwrap_or("");
                    if u.len() > 255 || pw.len() > 255 {
                        bail!("socks node `{label}`: username/password must be <= 255 bytes");
                    }
                    if ver != SocksVersion::V5 {
                        if u.as_bytes().contains(&0) {
                            bail!("socks4 node `{label}`: username (USERID) must not contain NUL");
                        }
                        if !pw.is_empty() {
                            tracing::warn!(
                                "socks4 node `{label}`: SOCKS4 has no password auth, `password` is ignored"
                            );
                        }
                    }
                }
                "wireguard" => {
                    use base64::Engine;
                    if p.server.is_empty() {
                        bail!("wireguard node `{label}` requires server");
                    }
                    if p.port == 0 {
                        bail!("wireguard node `{label}` requires a non-zero port");
                    }
                    let key_ok = |s: Option<&str>| {
                        s.and_then(|s| {
                            base64::engine::general_purpose::STANDARD
                                .decode(s.trim())
                                .ok()
                                .filter(|b| b.len() == 32)
                        })
                        .is_some()
                    };
                    if !key_ok(p.private_key.as_deref()) {
                        bail!(
                            "wireguard node `{label}` requires `private-key` \
                             (base64, exactly 32 bytes)"
                        );
                    }
                    if !key_ok(p.peer_public_key.as_deref()) {
                        bail!(
                            "wireguard node `{label}` requires `peer-public-key` \
                             (base64, exactly 32 bytes)"
                        );
                    }
                    if p.pre_shared_key.is_some() && !key_ok(p.pre_shared_key.as_deref()) {
                        bail!(
                            "wireguard node `{label}`: `pre-shared-key` must be \
                             base64 of exactly 32 bytes"
                        );
                    }
                    if p.local_address.is_empty() {
                        bail!(
                            "wireguard node `{label}` requires `local-address` \
                             (e.g. [\"10.7.0.2/32\"])"
                        );
                    }
                    for cidr in &p.local_address {
                        if cidr.parse::<ipnet::IpNet>().is_err() {
                            bail!(
                                "wireguard node `{label}`: invalid local-address `{cidr}` \
                                 (expected CIDR like 10.7.0.2/32)"
                            );
                        }
                    }
                    if let Some(mtu) = p.wg_mtu {
                        // 最小合法 IP 包 576(RFC 791) 对应 WG MTU 576；上限受 WG
                        // 数据包 65535 限制（IP 包 + 32 字节封装头）
                        if !(576..=65000).contains(&mtu) {
                            bail!(
                                "wireguard node `{label}`: mtu {mtu} out of range [576, 65000]"
                            );
                        }
                    }
                }
                other => bail!("proxy node `{label}`: unsupported type={other}; use hysteria2, tuic, anytls, naive, vless, vmess, trojan, shadowsocks, socks5, socks4, socks4a or wireguard"),
            }
        }
        let names: Vec<&str> = self.proxies.iter().map(|p| p.name.as_str()).collect();
        if names.len() != names.iter().collect::<std::collections::HashSet<_>>().len() {
            bail!("duplicate proxy node name in proxies");
        }

        // --- proxy-groups ---
        let mut group_names = std::collections::HashSet::new();
        for (i, g) in self.proxy_groups.iter().enumerate() {
            if g.name.trim().is_empty() {
                bail!("proxy-groups[{i}] requires a non-empty `name`");
            }
            // Only direct/block/reject are reserved for groups. Names like
            // `PROXY` / `proxy` are allowed (mihomo-compatible); `final`/`proxy`
            // remain reserved only for leaf `proxies:` node names.
            if ["direct", "block", "reject"]
                .iter()
                .any(|r| r.eq_ignore_ascii_case(&g.name))
            {
                bail!(
                    "proxy-groups[{i}]: name `{}` is reserved (direct/block/reject)",
                    g.name
                );
            }
            if names.iter().any(|n| n.eq_ignore_ascii_case(&g.name)) {
                bail!(
                    "proxy-groups[{i}]: name `{}` collides with a proxies node",
                    g.name
                );
            }
            if !group_names.insert(g.name.to_ascii_lowercase()) {
                bail!("duplicate proxy-group name `{}`", g.name);
            }
            let ty = g.ty.to_ascii_lowercase();
            if !matches!(
                ty.as_str(),
                "select"
                    | "url-test"
                    | "urltest"
                    | "fallback"
                    | "load-balance"
                    | "loadbalance"
                    | "relay"
            ) {
                bail!(
                    "proxy-groups[{i}] (`{}`): unsupported type `{}`                      (supported: select, url-test, fallback, load-balance, relay)",
                    g.name,
                    g.ty
                );
            }
            if g.proxies.is_empty()
                && g.r#use.is_empty()
                && !g.include_all_proxies
                && !g.include_all_providers
            {
                bail!(
                    "proxy-groups[{i}] (`{}`): need `proxies`, `use`, or include-all-*",
                    g.name
                );
            }
            for u in &g.r#use {
                if !self.proxy_providers.contains_key(u) {
                    bail!(
                        "proxy-groups[{i}] (`{}`): unknown proxy-provider `{u}`",
                        g.name
                    );
                }
            }
            let glabel = format!("proxy-groups[{i}] (`{}`)", g.name);
            if let Some(f) = &g.filter {
                validate_group_regex(&glabel, "filter", f)?;
            }
            if let Some(f) = &g.exclude_filter {
                validate_group_regex(&glabel, "exclude-filter", f)?;
            }
            if let Some(st) = &g.strategy {
                let s = st.to_ascii_lowercase();
                if !matches!(
                    s.as_str(),
                    "round-robin" | "roundrobin" | "consistent-hashing" | "consistenthashing" | "sticky-sessions" | "stickysessions"
                ) {
                    bail!(
                        "proxy-groups[{i}] (`{}`): unsupported strategy `{st}`",
                        g.name
                    );
                }
            }
        }
        // proxy-providers
        for (name, pp) in &self.proxy_providers {
            let ty = pp.ty.to_ascii_lowercase();
            match ty.as_str() {
                "file" => {
                    if pp.path.as_ref().map(|p| p.as_os_str().is_empty()).unwrap_or(true) {
                        bail!("proxy-providers.`{name}`: `path` is required for type file");
                    }
                }
                "http" => {
                    if pp.url.as_ref().map(|u| u.trim().is_empty()).unwrap_or(true) {
                        bail!("proxy-providers.`{name}`: `url` is required for type http");
                    }
                    if !pp.url.as_deref().unwrap_or("").contains("://") {
                        bail!(
                            "proxy-providers.`{name}`: `url` must include a scheme (http:// or https://)"
                        );
                    }
                }
                other => bail!(
                    "proxy-providers.`{name}`: type must be `file` or `http` (got `{other}`)"
                ),
            }
            if let Some(f) = &pp.filter {
                validate_group_regex(name, "filter", f)?;
            }
            if let Some(f) = &pp.exclude_filter {
                validate_group_regex(name, "exclude-filter", f)?;
            }
        }
        // Member references: node / group / DIRECT / REJECT. Groups may
        // reference each other; cycles are rejected after building the graph.
        let all_group: std::collections::HashSet<String> = self
            .proxy_groups
            .iter()
            .map(|g| g.name.to_ascii_lowercase())
            .collect();
        let all_node: std::collections::HashSet<String> = self
            .proxies
            .iter()
            .map(|p| p.name.to_ascii_lowercase())
            .collect();
        for (i, g) in self.proxy_groups.iter().enumerate() {
            for m in &g.proxies {
                let key = m.to_ascii_lowercase();
                if key == "direct" || key == "reject" || key == "block" {
                    continue;
                }
                if all_node.contains(&key) || all_group.contains(&key) {
                    continue;
                }
                // May come from a proxy-provider loaded at runtime.
                if !self.proxy_providers.is_empty() || g.include_all_providers {
                    continue;
                }
                bail!(
                    "proxy-groups[{i}] (`{}`): unknown member `{m}`                      (must be a proxies name, another group, DIRECT, or REJECT)",
                    g.name
                );
            }
            if let Some(sel) = &g.selected {
                let key = sel.to_ascii_lowercase();
                let ok = g.proxies.iter().any(|m| m.eq_ignore_ascii_case(sel))
                    || key == "direct"
                    || key == "reject"
                    || key == "block";
                if !ok {
                    bail!(
                        "proxy-groups[{i}] (`{}`): selected `{sel}` is not in proxies list",
                        g.name
                    );
                }
            }
        }
        // Simple cycle detection among groups.
        {
            use std::collections::HashMap;
            let mut edges: HashMap<String, Vec<String>> = HashMap::new();
            for g in &self.proxy_groups {
                let from = g.name.to_ascii_lowercase();
                let deps: Vec<String> = g
                    .proxies
                    .iter()
                    .map(|m| m.to_ascii_lowercase())
                    .filter(|m| all_group.contains(m))
                    .collect();
                edges.insert(from, deps);
            }
            fn has_cycle(
                node: &str,
                edges: &HashMap<String, Vec<String>>,
                stack: &mut std::collections::HashSet<String>,
                seen: &mut std::collections::HashSet<String>,
            ) -> bool {
                if !stack.insert(node.to_string()) {
                    return true;
                }
                if seen.insert(node.to_string()) {
                    if let Some(deps) = edges.get(node) {
                        for d in deps {
                            if has_cycle(d, edges, stack, seen) {
                                return true;
                            }
                        }
                    }
                }
                stack.remove(node);
                false
            }
            let mut seen = std::collections::HashSet::new();
            let mut stack = std::collections::HashSet::new();
            for g in edges.keys() {
                if has_cycle(g, &edges, &mut stack, &mut seen) {
                    bail!("proxy-groups: cycle detected involving `{g}`");
                }
            }
        }

        let known = self.outbound_names();

        // 端口 fail-fast：显式 0 一律拒绝；想关闭某个入站就省略字段。
        if self.global.mixed_port == Some(0) {
            bail!("mixed-port cannot be 0; omit the field to disable the inbound");
        }
        if self.global.http_port == Some(0) {
            bail!("http-port cannot be 0; omit the field to disable the inbound");
        }
        if self.global.socks_port == Some(0) {
            bail!("socks-port cannot be 0; omit the field to disable the inbound");
        }
        if self.global.tproxy_port == Some(0) {
            bail!("tproxy-port cannot be 0; omit the field to disable the inbound");
        }
        if self.global.redir_port == Some(0) {
            bail!("redir-port cannot be 0; omit the field to disable the inbound");
        }
        if self.dns.port == Some(0) {
            bail!("dns.port cannot be 0; omit `port` (hijack-only mode) or the whole dns block");
        }
        // bind-address: only 0.0.0.0 (LAN) or 127.0.0.1 (loopback).
        // Dual-stack vs IPv4-only is controlled solely by top-level `ipv6`.
        {
            let b = self.global.bind_address.trim();
            if b == "localhost" {
                self.global.bind_address = "127.0.0.1".into();
            } else if b != "0.0.0.0" && b != "127.0.0.1" {
                bail!(
                    "bind-address must be \"0.0.0.0\" or \"127.0.0.1\" (got `{b}`); \
                     use top-level `ipv6: true/false` to control IPv6 listening"
                );
            } else {
                self.global.bind_address = b.to_string();
            }
        }
        // DNS 模块关闭时，任何依赖 DNS 模块应答的劫持路径都必须为空（fail-fast）。
        if !self.dns.enable {
            if self.dns.route_hijack {
                bail!("dns.route-hijack requires dns.enable=true (DNS module is disabled)");
            }
            if !self.tun.dns_hijack.is_empty() {
                bail!("tun.dns-hijack requires dns.enable=true (DNS module is disabled)");
            }
        }
        self.global.api_secret = self.global.api_secret.trim().to_string();

        if self.dns.enable {
            let mode = self.dns.mode.to_ascii_lowercase();
            if mode != "redir-host" && mode != "fakeip" {
                bail!("dns.mode must be redir-host or fakeip");
            }
            self.dns.mode = mode;
            // Effective DNS IPv6: top-level ipv6=false forces A-only regardless of dns.ipv6.
            let effective_dns_ipv6 = self.global.ipv6 && self.dns.ipv6;
            if self.dns.mode == "fakeip" {
                if self.dns.fakeip_range.as_ref().map(|s| s.is_empty()).unwrap_or(true)
                    && self.dns.fakeip6_range.as_ref().map(|s| s.is_empty()).unwrap_or(true)
                {
                    bail!("fakeip mode requires fakeip-range and/or fakeip6-range");
                }
                if let Some(r) = &self.dns.fakeip_range {
                    r.parse::<ipnet::IpNet>().map_err(|e| anyhow::anyhow!("fakeip-range: {e}"))?;
                }
                if let Some(r) = &self.dns.fakeip6_range {
                    r.parse::<ipnet::IpNet>().map_err(|e| anyhow::anyhow!("fakeip6-range: {e}"))?;
                }
                if !effective_dns_ipv6
                    && self.dns.fakeip_range.as_ref().map(|s| s.is_empty()).unwrap_or(true)
                {
                    bail!("ipv6=false requires fakeip-range");
                }
                let fmode = self.dns.fakeip_filter_mode.to_ascii_lowercase();
                if fmode != "blacklist" && fmode != "whitelist" {
                    bail!("dns.fakeip-filter-mode must be blacklist or whitelist");
                }
                self.dns.fakeip_filter_mode = fmode;
                if self.dns.fakeip_filter_mode == "whitelist" && self.dns.fakeip_filter.is_empty() {
                    bail!("fakeip-filter-mode=whitelist requires non-empty fakeip-filter");
                }
            }
            let bootstrap = self
                .dns
                .default_nameserver
                .as_deref()
                .context("dns.enable=true requires dns.default-nameserver")?;
            crate::dns::parse_nameserver(bootstrap).context("invalid default-nameserver")?;
            // default-nameserver 是 bootstrap 本身，不能依赖任何解析：必须是纯 IP。
            {
                let raw = bootstrap.trim();
                let host_part = raw.rsplit("://").next().unwrap_or(raw);
                let host_part = host_part.split('/').next().unwrap_or(host_part);
                let host = if let Some(end) = host_part.find(']') {
                    &host_part[1..end]
                } else {
                    host_part.rsplit_once(':').map(|(h, _)| h).unwrap_or(host_part)
                };
                if host.parse::<std::net::IpAddr>().is_err() {
                    bail!("default-nameserver must be a pure IP address (got {host})");
                }
            }
        }

        // rule-providers: .ars binary or plaintext (yaml/json/list/text)
        let rulesets = self.ruleset_list(None)?;
        let ruleset_names: std::collections::HashSet<&str> =
            rulesets.iter().map(|r| r.name.as_str()).collect();

        // route（原 rules:，出站可为 direct/block/reject 别名或节点名）
        if self.route.is_empty() {
            bail!("route must not be empty; need a final MATCH rule");
        }
        let parsed = self.parsed_rules()?;
        let last = parsed.last().unwrap();
        if !last.is_match() {
            bail!("last route rule must be MATCH,<outbound>");
        }
        for (i, r) in parsed.iter().enumerate() {
            if i + 1 == parsed.len() {
                continue;
            }
            if r.is_match() {
                bail!("MATCH is only allowed as the last route rule (found at route[{i}])");
            }
            if let Some(name) = r.ruleset_name() {
                if !ruleset_names.contains(name) {
                    bail!("route[{i}]: unknown rule-provider `{name}`");
                }
            }
            if !known_has(&known, &r.outbound) {
                bail!(
                    "route[{i}]: unknown outbound `{}`; use direct/DIRECT, block/BLOCK, \
                     reject/REJECT, a proxies name, or a proxy-groups name",
                    r.outbound
                );
            }
        }
        if !known_has(&known, &last.outbound) {
            bail!(
                "MATCH: unknown outbound `{}`; use direct/DIRECT, block/BLOCK, \
                 reject/REJECT, a proxies name, or a proxy-groups name",
                last.outbound
            );
        }

        // DNS 出站选择策略校验（rule-follow-route / dns.rules / nameserver）
        if self.dns.enable && self.dns.rule_follow_route {
            if !self.dns.rules.is_empty() {
                bail!("dns.rules is only used with rule-follow-route=false");
            }
            if self.dns.nameserver.is_some() {
                bail!("dns.nameserver is only used with rule-follow-route=false");
            }
            let direct = self
                .dns
                .direct_nameserver
                .as_deref()
                .unwrap_or_default()
                .trim()
                .to_string();
            if direct.is_empty() {
                bail!("rule-follow-route=true requires dns.direct-nameserver");
            }
            let proxy = self
                .dns
                .proxy_nameserver
                .as_deref()
                .unwrap_or_default()
                .trim()
                .to_string();
            if proxy.is_empty() {
                bail!("rule-follow-route=true requires dns.proxy-nameserver");
            }
            crate::dns::parse_nameserver(&direct).context("invalid direct-nameserver")?;
            crate::dns::parse_nameserver(&proxy).context("invalid proxy-nameserver")?;
        } else if self.dns.enable {
            if self.dns.direct_nameserver.is_some() || self.dns.proxy_nameserver.is_some() {
                bail!(
                    "direct-nameserver/proxy-nameserver are only used with \
                     rule-follow-route=true; use dns.rules + nameserver instead"
                );
            }
            let node_names: Vec<String> = self.proxies.iter().map(|p| p.name.clone()).collect();
            for (i, line) in self.dns.rules.iter().enumerate() {
                let r = parse_dns_rule_line(line).with_context(|| format!("dns.rules[{i}]"))?;
                if r.is_match() && i + 1 != self.dns.rules.len() {
                    bail!("dns.rules[{i}]: MATCH is only allowed as the last dns rule");
                }
                if let Some(name) = r.ruleset_name() {
                    let rs = rulesets
                        .iter()
                        .find(|rs| rs.name == name)
                        .ok_or_else(|| {
                            anyhow::anyhow!("dns.rules[{i}] references unknown rule-provider {name}")
                        })?;
                    if rs.ty != "domain" && rs.ty != "classical" {
                        bail!("dns.rules[{i}] `{name}` must be a domain or classical rule-provider");
                    }
                }
                validate_dns_upstream(&r.upstream, &node_names)
                    .with_context(|| format!("dns.rules[{i}]"))?;
            }
            if self.dns.rules.is_empty() {
                let ns = self.dns.nameserver.as_deref().unwrap_or_default().trim();
                if ns.is_empty() {
                    bail!("rule-follow-route=false without dns.rules requires dns.nameserver");
                }
                crate::dns::parse_nameserver(ns).context("invalid dns.nameserver")?;
            }
        }

        if self.dns.enable && self.dns.mode == "fakeip" {
            let check = |names: &[String], field: &str| -> Result<()> {
                for name in names {
                    let rs = rulesets
                        .iter()
                        .find(|r| &r.name == name)
                        .ok_or_else(|| anyhow::anyhow!("{field} references unknown rule-provider {name}"))?;
                    if rs.ty != "domain" && rs.ty != "classical" {
                        bail!("{field} `{name}` must be a domain or classical rule-provider");
                    }
                }
                Ok(())
            };
            check(&self.dns.fakeip_filter, "fakeip-filter")?;
        }

        // ── ip-auto-route ──────────────────────────────────────────────
        self.validate_ip_auto_route()?;

        Ok(())
    }

    /// Validate `ip-auto-route:` against mutual exclusion and required base configs.
    ///
    /// `&mut self` because it may auto-assign `global.mark` (loop prevention).
    // 非 Linux/Android 上首个块直接 bail!，末尾的 `Ok(())` 不可达（clippy -D warnings）。
    #[allow(unreachable_code)]
    fn validate_ip_auto_route(&mut self) -> Result<()> {
        let iar = &self.ip_auto_route;
        if !iar.enable {
            return Ok(());
        }

        #[cfg(not(any(target_os = "linux", target_os = "android")))]
        {
            bail!("ip-auto-route is only supported on Linux and Android");
        }

        #[cfg(any(target_os = "linux", target_os = "android"))]
        {
            // Mutual exclusion with TUN auto-route / auto-redirect.
            if self.tun.auto_route {
                bail!(
                    "ip-auto-route.enable is mutually exclusive with tun.auto-route; disable one of them"
                );
            }
            if self.tun.auto_redirect {
                bail!(
                    "ip-auto-route.enable is mutually exclusive with tun.auto-redirect; disable one of them"
                );
            }
            // External TUN fd (Android VpnService / sing-tun FileDescriptor):
            // the OS already owns addresses + routing, and `tun::run_tun`
            // force-disables tun.auto-route in that mode. ip-auto-route would
            // install a second, conflicting control plane (fwmark rules,
            // catch-all into our own table) — reject explicitly instead of
            // letting the two diverge.
            if self.tun.enable && self.tun.is_external_fd() {
                bail!(
                    "ip-auto-route.enable is mutually exclusive with an external TUN \
                     file-descriptor (tun.file-descriptor / ANT_TUN_FD); the OS/VpnService \
                     owns routing in that mode"
                );
            }

            let tcp = iar
                .tcp_mode
                .as_deref()
                .map(str::trim)
                .filter(|s| !s.is_empty())
                .map(|s| s.to_ascii_lowercase());
            let udp = iar
                .udp_mode
                .as_deref()
                .map(str::trim)
                .filter(|s| !s.is_empty())
                .map(|s| s.to_ascii_lowercase());

            if tcp.is_none() && udp.is_none() {
                bail!(
                    "ip-auto-route.enable=true requires at least one of tcp-mode / udp-mode \
                     (redir|tproxy|tun for TCP; tproxy|tun for UDP)"
                );
            }

            if let Some(ref m) = tcp {
                match m.as_str() {
                    "redir" | "tproxy" | "tun" => {}
                    other => bail!(
                        "ip-auto-route.tcp-mode `{other}` is invalid; expected redir|tproxy|tun"
                    ),
                }
            }
            if let Some(ref m) = udp {
                match m.as_str() {
                    "tproxy" | "tun" => {}
                    "redir" => bail!(
                        "ip-auto-route.udp-mode `redir` is not supported; use tproxy or tun"
                    ),
                    other => bail!(
                        "ip-auto-route.udp-mode `{other}` is invalid; expected tproxy|tun"
                    ),
                }
            }

            let needs_redir = tcp.as_deref() == Some("redir");
            let needs_tproxy =
                tcp.as_deref() == Some("tproxy") || udp.as_deref() == Some("tproxy");
            let needs_tun = tcp.as_deref() == Some("tun") || udp.as_deref() == Some("tun");

            if needs_redir {
                match self.global.redir_port {
                    Some(p) if p > 0 => {}
                    _ => bail!(
                        "ip-auto-route.tcp-mode=redir requires a non-zero top-level `redir-port`"
                    ),
                }
            }
            if needs_tproxy {
                match self.global.tproxy_port {
                    Some(p) if p > 0 => {}
                    _ => bail!(
                        "ip-auto-route tcp/udp-mode=tproxy requires a non-zero top-level `tproxy-port`"
                    ),
                }
            }
            if needs_tun {
                if !self.tun.enable {
                    bail!("ip-auto-route mode=tun requires tun.enable=true");
                }
                if self.tun.address.is_empty() {
                    bail!("ip-auto-route mode=tun requires tun.address to be configured");
                }
            }

            if iar.dns_hijack_to_port {
                if !self.dns.enable {
                    bail!("ip-auto-route.dns-hijack-to-port requires dns.enable=true");
                }
                if self.dns.listen_port() == 0 {
                    bail!(
                        "ip-auto-route.dns-hijack-to-port requires a non-zero dns.port \
                         (DNS must listen on a real port)"
                    );
                }
            }

            if iar.fakeip_ping_hijack {
                if !self.dns.enable {
                    bail!("ip-auto-route.fakeip-ping-hijack requires dns.enable=true");
                }
                if self.dns.mode != "fakeip" {
                    bail!(
                        "ip-auto-route.fakeip-ping-hijack requires dns.mode=fakeip"
                    );
                }
                let has_range = self
                    .dns
                    .fakeip_range
                    .as_deref()
                    .map(|s| !s.trim().is_empty())
                    .unwrap_or(false)
                    || self
                        .dns
                        .fakeip6_range
                        .as_deref()
                        .map(|s| !s.trim().is_empty())
                        .unwrap_or(false);
                if !has_range {
                    bail!(
                        "ip-auto-route.fakeip-ping-hijack requires dns.fakeip-range \
                         and/or dns.fakeip6-range"
                    );
                }
            }

            if iar.lan_proxy
                && (iar.lan_interface.is_empty()
                    || iar
                        .lan_interface
                        .iter()
                        .all(|s| s.trim().is_empty()))
            {
                bail!(
                    "ip-auto-route.lan-proxy=true requires a non-empty lan-interface list                      (to avoid hijacking the wrong NIC)"
                );
            }

            match iar
                .bypass_type
                .as_deref()
                .map(|s| s.trim().to_ascii_lowercase())
                .as_deref()
            {
                None | Some("") | Some("cgroup") | Some("mark") => {}
                Some(other) => bail!(
                    "ip-auto-route.bypass-type `{other}` is invalid; expected cgroup|mark"
                ),
            }

            // `mark` is ant's SO_MARK. With `bypass-type: mark` it is what the
            // hijack rules match on to skip ant's own traffic; with `cgroup` it
            // is still set (TUN auto-route relies on it) but no rule depends on
            // it. Auto-assign 255 like TUN auto-route does so the value always
            // reaches `app::sockopt::set_fwmark`.
            if self.global.mark == 0 {
                self.global.mark = 255;
                tracing::info!("ip-auto-route: top-level `mark` not set, using 255");
            }

            // The SO_MARK must never alias the hijack fwmark: `ip rule fwmark
            // <hijack>/<mask>` would then match every socket ant opens and send
            // its own traffic into lo/TUN → tproxy → ant → loop. nexa avoids
            // this by construction (its core carries no fwmark); ant shares
            // `mark` with TUN auto-route, so we have to check.
            let mask = crate::ip_auto_route::FW_MASK;
            for fw in [
                crate::ip_auto_route::TPROXY_FWMARK,
                crate::ip_auto_route::TUN_FWMARK,
            ] {
                if self.global.mark & mask == fw & mask {
                    bail!(
                        "top-level `mark` 0x{:x} collides with the ip-auto-route hijack fwmark \
                         0x{:x}/0x{:x} (ant's own traffic would be routed back into itself); \
                         choose a different `mark`",
                        self.global.mark,
                        fw,
                        mask
                    );
                }
            }
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const BASE: &str = r#"
mixed-port: 7898
dns:
  port: 5353
  direct-nameserver: "223.5.5.5:53"
  proxy-nameserver: "https://1.1.1.1/dns-query"
  default-nameserver: "223.5.5.5:53"
"#;

    fn two_nodes() -> String {
        r#"
proxies:
  - name: hy2-main
    type: hysteria2
    server: 1.2.3.4
    port: 443
    password: pw
  - name: vless-xhttp
    type: vless
    server: 1.2.3.4
    port: 443
    uuid: aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa
    network: xhttp
    tls: true
"#
        .into()
    }

    fn rules_and_routes(final_ob: &str) -> String {
        format!(
            r#"
rule-providers:
  cn:
    type: file
    behavior: domain
    path: /tmp/cn.ars
route:
  - RULE-SET,cn,vless-xhttp
  - MATCH,{final_ob}
"#
        )
    }

    fn parse(yaml_text: &str) -> Result<Config> {
        let mut cfg: Config = serde_yaml::from_str(yaml_text)?;
        cfg.validate()?;
        Ok(cfg)
    }

    #[test]
    fn resolve_ruleset_paths_joins_relative_only() {
        let yaml = format!(
            "{BASE}{}{}",
            two_nodes(),
            r#"
rule-providers:
  cn:
    type: file
    behavior: domain
    path: cn.ars
  ads:
    type: file
    behavior: domain
    path: ./rules/ads.ars
  abs:
    type: file
    behavior: domain
    path: /var/lib/ant/abs.ars
route:
  - RULE-SET,cn,vless-xhttp
  - MATCH,hy2-main
"#
        );
        let mut cfg = parse(&yaml).unwrap();
        let base = std::path::Path::new("/opt/ant");
        cfg.resolve_ruleset_paths(base);
        let list = cfg.ruleset_list(Some(base)).unwrap();
        let path_of = |n: &str| -> std::path::PathBuf {
            let RulesetStorage::File(p) = &list.iter().find(|r| r.name == n).unwrap().storage;
            p.clone()
        };
        assert_eq!(path_of("cn"), base.join("cn.ars"));
        assert_eq!(path_of("ads"), base.join("rules").join("ads.ars"));
        assert_eq!(path_of("abs"), std::path::PathBuf::from("/var/lib/ant/abs.ars"));
    }

    #[test]
    fn multi_node_and_named_routing_ok() {
        let cfg = parse(&format!("{BASE}{}{}", two_nodes(), rules_and_routes("hy2-main"))).unwrap();
        assert_eq!(cfg.proxies.len(), 2);
        assert_eq!(cfg.proxies[0].name, "hy2-main");
        let parsed = cfg.parsed_rules().unwrap();
        assert_eq!(parsed.len(), 2);
        assert_eq!(parsed[0].ruleset_name(), Some("cn"));
        assert_eq!(parsed[0].outbound, "vless-xhttp");
        assert!(parsed[1].is_match());
        assert_eq!(parsed[1].outbound, "hy2-main");
    }

    #[test]
    fn match_accepts_direct_alias() {
        let cfg = parse(&format!("{BASE}{}{}", two_nodes(), rules_and_routes("DIRECT"))).unwrap();
        let parsed = cfg.parsed_rules().unwrap();
        assert_eq!(parsed.last().unwrap().outbound, "direct");
    }

    #[test]
    fn match_accepts_reject_as_block() {
        let yaml = format!(
            "{BASE}{}{}",
            two_nodes(),
            r#"
rule-providers:
  cn:
    type: file
    behavior: domain
    path: /tmp/cn.ars
route:
  - RULE-SET,cn,REJECT
  - MATCH,hy2-main
"#
        );
        let cfg = parse(&yaml).unwrap();
        let parsed = cfg.parsed_rules().unwrap();
        assert_eq!(parsed[0].outbound, "block");
    }

    #[test]
    fn route_accepts_block_alias() {
        let yaml = format!(
            "{BASE}{}{}",
            two_nodes(),
            r#"
rule-providers:
  cn:
    type: file
    behavior: domain
    path: /tmp/cn.ars
route:
  - RULE-SET,cn,block
  - MATCH,DIRECT
"#
        );
        let cfg = parse(&yaml).unwrap();
        let parsed = cfg.parsed_rules().unwrap();
        assert_eq!(parsed[0].outbound, "block");
        assert_eq!(parsed[1].outbound, "direct");
    }

    #[test]
    fn reserved_node_name_block_rejected() {
        let yaml = format!(
            "{BASE}\nproxies:\n  - name: BLOCK\n    type: hysteria2\n    server: 1.2.3.4\n    port: 443\n    password: pw\nroute:\n  - MATCH,direct\n"
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("reserved"), "{err}");
    }

    #[test]
    fn old_rules_key_rejected() {
        // 顶层字段已更名为 route:，旧 rules: 直接 fail-fast。
        let yaml = format!(
            "{BASE}{}{}",
            two_nodes(),
            r#"
rule-providers:
  cn:
    type: file
    behavior: domain
    path: /tmp/cn.ars
rules:
  - MATCH,direct
"#
        );
        assert!(parse(&yaml).is_err());
    }

    #[test]
    fn missing_name_rejected() {
        let yaml = format!(
            "{BASE}\nproxies:\n  - type: hysteria2\n    server: 1.2.3.4\n    port: 443\n    password: pw\nroute:\n  - MATCH,direct\n"
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("requires a non-empty `name`"), "{err}");
    }

    #[test]
    fn duplicate_name_rejected() {
        let yaml = format!(
            "{BASE}\nproxies:\n  - name: a\n    type: hysteria2\n    server: 1.2.3.4\n    port: 443\n    password: pw\n  - name: a\n    type: hysteria2\n    server: 1.2.3.4\n    port: 443\n    password: pw\nroute:\n  - MATCH,direct\n"
        );
        assert!(parse(&yaml).is_err());
    }

    #[test]
    fn reserved_node_name_rejected() {
        let yaml = format!(
            "{BASE}\nproxies:\n  - name: direct\n    type: hysteria2\n    server: 1.2.3.4\n    port: 443\n    password: pw\nroute:\n  - MATCH,direct\n"
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("reserved"), "{err}");
    }

    #[test]
    fn reserved_node_name_reject_rejected() {
        let yaml = format!(
            "{BASE}\nproxies:\n  - name: REJECT\n    type: hysteria2\n    server: 1.2.3.4\n    port: 443\n    password: pw\nroute:\n  - MATCH,direct\n"
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("reserved"), "{err}");
    }

    #[test]
    fn unknown_route_outbound_rejected() {
        let yaml = format!("{BASE}{}{}", two_nodes(), rules_and_routes("no-such-node"));
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("unknown outbound"), "{err}");
    }

    #[test]
    fn last_rule_must_be_match() {
        let yaml = format!(
            "{BASE}{}\nrule-providers:\n  cn:\n    type: file\n    behavior: domain\n    path: /tmp/cn.ars\nroute:\n  - RULE-SET,cn,direct\n",
            two_nodes()
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("MATCH"), "{err}");
    }

    /// 在 BASE 的 dns: 块中（default-nameserver 行之后）追加额外字段。
    fn base_dns_extra(extra: &str) -> String {
        BASE.replacen(
            "  default-nameserver: \"223.5.5.5:53\"",
            &format!("  default-nameserver: \"223.5.5.5:53\"\n{extra}"),
            1,
        )
    }

    #[test]
    fn follow_route_requires_direct_and_proxy_nameserver() {
        let yaml = format!(
            "mixed-port: 7898\ndns:\n  port: 5353\n  default-nameserver: \"223.5.5.5:53\"\n{}{}",
            two_nodes(),
            rules_and_routes("direct")
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("direct-nameserver"), "{err}");
    }

    #[test]
    fn follow_route_rejects_dns_rules() {
        let yaml = format!(
            "{}{}{}",
            base_dns_extra("  rules:\n    - MATCH,udp://223.5.5.5:53\n"),
            two_nodes(),
            rules_and_routes("direct")
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(
            err.contains("dns.rules is only used with rule-follow-route=false"),
            "{err}"
        );
    }

    #[test]
    fn follow_route_rejects_nameserver() {
        let yaml = format!(
            "{}{}{}",
            base_dns_extra("  nameserver: \"udp://223.5.5.5:53\"\n"),
            two_nodes(),
            rules_and_routes("direct")
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(
            err.contains("dns.nameserver is only used with rule-follow-route=false"),
            "{err}"
        );
    }

    #[test]
    fn custom_rules_reject_direct_nameserver() {
        let yaml = format!(
            "{}{}{}",
            custom_dns_base("  nameserver: \"udp://223.5.5.5:53\"\n  direct-nameserver: \"223.5.5.5:53\"\n"),
            two_nodes(),
            rules_and_routes("direct")
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("rule-follow-route=true"), "{err}");
    }

    /// false 模式基础配置：dns 块显式构造，不含 direct/proxy-nameserver。
    fn custom_dns_base(extra: &str) -> String {
        format!(
            "mixed-port: 7898\ndns:\n  port: 5353\n  default-nameserver: \"223.5.5.5:53\"\n  rule-follow-route: false\n{extra}"
        )
    }

    fn dns_rules_config(dns_extra: &str) -> String {
        format!(
            "{}{}{}",
            custom_dns_base(dns_extra),
            two_nodes(),
            rules_and_routes("direct")
        )
    }

    #[test]
    fn custom_dns_rules_ok() {
        let yaml = dns_rules_config(
            r#"  rules:
    - RULE-SET,cn,udp://223.5.5.5:53
    - MATCH,rcode://success
"#,
        );
        let cfg = parse(&yaml).unwrap();
        assert_eq!(cfg.dns.rules.len(), 2);
        let r0 = parse_dns_rule_line(&cfg.dns.rules[0]).unwrap();
        assert_eq!(r0.ruleset_name(), Some("cn"));
        assert_eq!(r0.upstream, "udp://223.5.5.5:53");
    }

    #[test]
    fn custom_dns_rules_match_must_be_last() {
        let yaml = dns_rules_config(
            r#"  rules:
    - MATCH,udp://223.5.5.5:53
    - RULE-SET,cn,udp://223.5.5.5:53
"#,
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("MATCH is only allowed as the last"), "{err}");
    }

    #[test]
    fn custom_dns_rules_lowercase_rejected() {
        let yaml = dns_rules_config(
            r#"  rules:
    - match,udp://223.5.5.5:53
"#,
        );
        let err = format!("{:#}", parse(&yaml).unwrap_err());
        assert!(err.contains("uppercase"), "{err:#}");
    }

    #[test]
    fn custom_dns_rules_outbound_names_rejected() {
        for upstream in ["direct", "REJECT", "block", "hy2-main", "vless-xhttp"] {
            let yaml = dns_rules_config(&format!(
                "  rules:\n    - MATCH,{upstream}\n"
            ));
            let err = format!("{:#}", parse(&yaml).unwrap_err());
            assert!(
                err.contains("nameserver url or rcode://success"),
                "upstream `{upstream}`: {err}"
            );
        }
    }

    #[test]
    fn custom_dns_rules_unknown_ruleset_rejected() {
        let yaml = dns_rules_config(
            r#"  rules:
    - RULE-SET,nope,udp://223.5.5.5:53
    - MATCH,udp://223.5.5.5:53
"#,
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("unknown rule-provider"), "{err}");
    }

    #[test]
    fn custom_dns_without_rules_requires_nameserver() {
        let yaml = dns_rules_config("");
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("dns.nameserver"), "{err}");
    }

    #[test]
    fn custom_dns_nameserver_default_ok() {
        let yaml = dns_rules_config("  nameserver: \"udp://223.5.5.5:53\"\n");
        let cfg = parse(&yaml).unwrap();
        assert_eq!(cfg.dns.nameserver.as_deref(), Some("udp://223.5.5.5:53"));
        assert!(cfg.dns.direct_nameserver.is_none());
    }

    #[test]
    fn custom_dns_nameserver_rejects_outbound_name() {
        let yaml = dns_rules_config("  nameserver: \"hy2-main\"\n");
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("invalid dns.nameserver"), "{err}");
    }

    // ── dns enable / port 语义 ──────────────────────────────────

    fn minimal_config(body: &str) -> String {
        format!("{body}{}{}", two_nodes(), rules_and_routes("direct"))
    }

    #[test]
    fn dns_block_absent_means_disabled() {
        let cfg = parse(&minimal_config("mixed-port: 7898\n")).unwrap();
        assert!(!cfg.dns.enable);
        assert_eq!(cfg.dns.listen_port(), 0);
        assert!(cfg.dns.default_nameserver.is_none());
    }

    #[test]
    fn dns_enable_false_skips_nameserver_requirements() {
        let yaml = minimal_config(
            "mixed-port: 7898\ndns:\n  enable: false\n  route-hijack: false\n",
        );
        let cfg = parse(&yaml).unwrap();
        assert!(!cfg.dns.enable);
    }

    #[test]
    fn dns_block_present_defaults_enabled() {
        let yaml = minimal_config(
            "dns:\n  port: 5353\n  default-nameserver: \"223.5.5.5:53\"\n  rule-follow-route: false\n  nameserver: \"udp://223.5.5.5:53\"\n",
        );
        let cfg = parse(&yaml).unwrap();
        assert!(cfg.dns.enable);
        assert_eq!(cfg.dns.listen_port(), 5353);
    }

    #[test]
    fn dns_enabled_without_port_is_hijack_only() {
        let yaml = minimal_config(
            "dns:\n  default-nameserver: \"223.5.5.5:53\"\n  rule-follow-route: false\n  nameserver: \"udp://223.5.5.5:53\"\n",
        );
        let cfg = parse(&yaml).unwrap();
        assert!(cfg.dns.enable);
        assert_eq!(cfg.dns.listen_port(), 0);
    }

    #[test]
    fn dns_enabled_requires_default_nameserver() {
        let yaml = minimal_config(
            "dns:\n  port: 5353\n  rule-follow-route: false\n  nameserver: \"udp://223.5.5.5:53\"\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("default-nameserver"), "{err}");
    }

    #[test]
    fn dns_route_hijack_rejected_when_disabled() {
        let yaml = minimal_config(
            "dns:\n  enable: false\n  route-hijack: true\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("route-hijack requires dns.enable=true"), "{err}");
    }

    #[test]
    fn explicit_zero_ports_rejected() {
        for line in [
            "mixed-port: 0\n",
            "tproxy-port: 0\n",
            "redir-port: 0\n",
        ] {
            let yaml = minimal_config(&format!("{line}dns:\n  enable: false\n"));
            let err = parse(&yaml).unwrap_err().to_string();
            assert!(err.contains("cannot be 0"), "{line}: {err}");
        }
        let yaml = minimal_config("dns:\n  enable: true\n  port: 0\n  default-nameserver: \"223.5.5.5:53\"\n  rule-follow-route: false\n  nameserver: \"udp://223.5.5.5:53\"\n");
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("dns.port cannot be 0"), "{err}");
    }

    #[test]
    fn parse_rule_line_ok() {
        let r = parse_rule_line("RULE-SET, ads , REJECT").unwrap();
        assert_eq!(r.ruleset_name(), Some("ads"));
        assert_eq!(r.outbound, "block");
        assert!(!r.is_match());
        assert!(!r.no_resolve);
        let m = parse_rule_line("MATCH,hy2-main").unwrap();
        assert!(m.is_match());
        let nr = parse_rule_line("RULE-SET,cn-ip,DIRECT,no-resolve").unwrap();
        assert!(nr.no_resolve);
        assert_eq!(m.outbound, "hy2-main");
    }

    #[test]
    fn parse_dns_rule_line_ok() {
        let r = parse_dns_rule_line("RULE-SET, ads , udp://1.1.1.1:53").unwrap();
        assert_eq!(r.ruleset_name(), Some("ads"));
        assert_eq!(r.upstream, "udp://1.1.1.1:53");
        let m = parse_dns_rule_line("MATCH,rcode://success").unwrap();
        assert!(m.is_match());
        assert_eq!(m.upstream, "rcode://success");
        // type keywords are case-insensitive
    }

    #[test]
    fn validate_dns_upstream_accepts_nameserver_and_rcode() {
        let nodes = vec!["hy2-main".to_string()];
        validate_dns_upstream("udp://1.1.1.1:53", &nodes).unwrap();
        validate_dns_upstream("https://1.1.1.1/dns-query", &nodes).unwrap();
        validate_dns_upstream("rcode://success", &nodes).unwrap();
        for bad in ["direct", "BLOCK", "reject", "hy2-main", "rcode://nxdomain"] {
            assert!(validate_dns_upstream(bad, &nodes).is_err(), "{bad}");
        }
    }

    // ── ip-auto-route validation ─────────────────────────────────

    fn iar_base(extra: &str) -> String {
        // Minimal valid proxy stack + optional ip-auto-route block.
        // Do not use `\` line-continuations for indented YAML: Rust strips
        // leading whitespace after `\`, which would un-indent keys under
        // `dns:` and leave an empty dns block (enable defaults to true).
        // `concat!` + `format!` cannot use named `{extra}` capture — use `{}`.
        format!(
            concat!(
                "mixed-port: 7898\n",
                "redir-port: 7892\n",
                "tproxy-port: 7893\n",
                "dns:\n",
                "  enable: false\n",
                "{}",
                "{}",
                "{}",
            ),
            extra,
            two_nodes(),
            rules_and_routes("direct")
        )
    }

    #[test]
    fn iar_disabled_ok() {
        let cfg = parse(&iar_base("")).unwrap();
        assert!(!cfg.ip_auto_route.enable);
    }

    #[test]
    fn iar_enable_without_modes_fails() {
        let yaml = iar_base("ip-auto-route:\n  enable: true\n");
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(
            err.contains("tcp-mode") || err.contains("udp-mode"),
            "{err}"
        );
    }

    #[test]
    fn iar_invalid_tcp_mode_fails() {
        let yaml = iar_base(
            "ip-auto-route:\n  enable: true\n  tcp-mode: foo\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("tcp-mode"), "{err}");
    }

    #[test]
    fn iar_udp_redir_rejected() {
        let yaml = iar_base(
            "ip-auto-route:\n  enable: true\n  udp-mode: redir\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("udp-mode") && err.contains("redir"), "{err}");
    }

    #[test]
    fn iar_redir_requires_redir_port() {
        let yaml = format!(
            "mixed-port: 7898\n\
             dns:\n  enable: false\n\
             ip-auto-route:\n  enable: true\n  tcp-mode: redir\n\
             {}{}",
            two_nodes(),
            rules_and_routes("direct")
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("redir-port"), "{err}");
    }

    #[test]
    fn iar_tproxy_requires_tproxy_port() {
        let yaml = format!(
            "mixed-port: 7898\n\
             dns:\n  enable: false\n\
             ip-auto-route:\n  enable: true\n  tcp-mode: tproxy\n\
             {}{}",
            two_nodes(),
            rules_and_routes("direct")
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("tproxy-port"), "{err}");
    }

    #[test]
    fn iar_tun_requires_tun_enable() {
        let yaml = iar_base(
            "ip-auto-route:\n  enable: true\n  tcp-mode: tun\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("tun.enable"), "{err}");
    }

    #[test]
    fn iar_tun_requires_address() {
        let yaml = iar_base(
            "tun:\n  enable: true\n  address: []\n\
             ip-auto-route:\n  enable: true\n  tcp-mode: tun\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        // either address empty fails here or earlier tun validation
        assert!(
            err.contains("tun.address") || err.contains("address"),
            "{err}"
        );
    }

    #[test]
    fn iar_mutex_auto_route() {
        let yaml = iar_base(
            "tun:\n  enable: true\n  auto-route: true\n  address: [\"198.18.0.1/30\"]\n\
             ip-auto-route:\n  enable: true\n  tcp-mode: redir\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("auto-route"), "{err}");
    }

    #[test]
    fn iar_mutex_auto_redirect() {
        let yaml = iar_base(
            "tun:\n  enable: true\n  auto-redirect: true\n  auto-route: true\n  address: [\"198.18.0.1/30\"]\n\
             ip-auto-route:\n  enable: true\n  tcp-mode: redir\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(
            err.contains("auto-redirect") || err.contains("auto-route"),
            "{err}"
        );
    }

    #[test]
    fn iar_lan_proxy_requires_interface() {
        let yaml = iar_base(
            "ip-auto-route:\n  enable: true\n  tcp-mode: redir\n  lan-proxy: true\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("lan-interface"), "{err}");
    }

    #[test]
    fn iar_dns_hijack_requires_dns() {
        let yaml = iar_base(
            "ip-auto-route:\n  enable: true\n  tcp-mode: redir\n  dns-hijack-to-port: true\n",
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("dns.enable") || err.contains("dns"), "{err}");
    }

    #[test]
    fn iar_dns_hijack_requires_port() {
        let yaml = format!(
            "mixed-port: 7898\n\
             redir-port: 7892\n\
             dns:\n  enable: true\n  default-nameserver: \"223.5.5.5:53\"\n  rule-follow-route: false\n  nameserver: \"udp://223.5.5.5:53\"\n\
             ip-auto-route:\n  enable: true\n  tcp-mode: redir\n  dns-hijack-to-port: true\n\
             {}{}",
            two_nodes(),
            rules_and_routes("direct")
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("dns.port"), "{err}");
    }

    #[test]
    fn iar_fakeip_ping_requires_fakeip_mode() {
        let yaml = format!(
            "mixed-port: 7898\n\
             redir-port: 7892\n\
             dns:\n  enable: true\n  port: 5353\n  mode: redir-host\n  default-nameserver: \"223.5.5.5:53\"\n  rule-follow-route: false\n  nameserver: \"udp://223.5.5.5:53\"\n\
             ip-auto-route:\n  enable: true\n  tcp-mode: redir\n  fakeip-ping-hijack: true\n\
             {}{}",
            two_nodes(),
            rules_and_routes("direct")
        );
        let err = parse(&yaml).unwrap_err().to_string();
        assert!(err.contains("fakeip"), "{err}");
    }

    #[test]
    #[cfg(target_os = "linux")]
    fn iar_mark_auto_assigned() {
        let yaml = iar_base("ip-auto-route:\n  enable: true\n  tcp-mode: redir\n");
        let cfg = parse(&yaml).unwrap();
        // Loop prevention needs a non-zero mark shared with SO_MARK.
        assert_eq!(cfg.global.mark, 255);
    }

    #[test]
    fn iar_valid_redir_ok() {
        let yaml = iar_base(
            "ip-auto-route:\n  enable: true\n  tcp-mode: redir\n  lan-proxy: true\n  lan-interface: [eth0]\n",
        );
        let cfg = parse(&yaml).unwrap();
        assert!(cfg.ip_auto_route.enable);
        assert_eq!(cfg.ip_auto_route.tcp_mode.as_deref(), Some("redir"));
        assert_eq!(cfg.ip_auto_route.lan_interface, vec!["eth0".to_string()]);
    }

    #[test]
    fn iar_valid_tproxy_ok() {
        let yaml = iar_base(
            "ip-auto-route:\n  enable: true\n  tcp-mode: tproxy\n  udp-mode: tproxy\n",
        );
        let cfg = parse(&yaml).unwrap();
        assert_eq!(cfg.ip_auto_route.udp_mode.as_deref(), Some("tproxy"));
    }

    #[test]
    fn iar_valid_tun_ok() {
        let yaml = iar_base(
            "tun:\n  enable: true\n  address: [\"198.18.0.1/30\"]\n  auto-route: false\n  auto-redirect: false\n\
             ip-auto-route:\n  enable: true\n  tcp-mode: tun\n  udp-mode: tun\n",
        );
        let cfg = parse(&yaml).unwrap();
        assert_eq!(cfg.ip_auto_route.tcp_mode.as_deref(), Some("tun"));
        assert!(cfg.tun.enable);
    }
}
